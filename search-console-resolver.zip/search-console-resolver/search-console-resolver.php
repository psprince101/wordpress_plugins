<?php
/**
 * Plugin Name: Search Console Resolver
 * Description: Works on any WordPress site. Repairs the Search Console issues WordPress can fix safely, and reports the other indexing factors that still need a person.
 * Version: 1.9.0
 * Requires at least: 5.8
 * Tested up to: 7.1.4
 * Requires PHP: 7.4
 * License: GPLv2 or later
 * Text Domain: search-console-resolver
 * Update URI: https://search-console-resolver.invalid/
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SCR_VERSION', '1.9.0');

function scr_request_path() {
    $path = isset($_SERVER['REQUEST_URI']) ? wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH) : '';
    return is_string($path) ? $path : '';
}

function scr_is_sitemap_request() {
    $path = scr_request_path();
    if (preg_match('#/sitemap[^/]*\.xml$#i', $path)) {
        return true;
    }
    return isset($_GET['sitemap']) || isset($_GET['sitemap_n']);
}

function scr_is_machine_request() {
    if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
        return false;
    }
    if (scr_is_sitemap_request()) {
        return true;
    }
    $path = untrailingslashit(scr_request_path());
    if ($path === '/robots.txt') {
        return true;
    }
    return (bool) preg_match('#/(?:feed|comments/feed)$#', $path);
}

function scr_schema_has_price($node) {
    if (!is_array($node) || empty($node['offers'])) {
        return false;
    }
    $offers = $node['offers'];
    if (isset($offers['price']) && (float) $offers['price'] > 0) {
        return true;
    }
    if (!isset($offers[0]) || !is_array($offers)) {
        return false;
    }
    foreach ($offers as $offer) {
        if (is_array($offer) && isset($offer['price']) && (float) $offer['price'] > 0) {
            return true;
        }
    }
    return false;
}

function scr_schema_type_list($node) {
    if (!is_array($node) || !isset($node['@type'])) {
        return array();
    }
    return is_array($node['@type']) ? $node['@type'] : array($node['@type']);
}

function scr_schema_is_invalid($node) {
    $types = scr_schema_type_list($node);
    if (in_array('Product', $types, true) && !scr_schema_has_price($node)) {
        return true;
    }
    if (in_array('AggregateRating', $types, true)) {
        $count = isset($node['ratingCount']) ? (int) $node['ratingCount'] : (isset($node['reviewCount']) ? (int) $node['reviewCount'] : 0);
        $value = isset($node['ratingValue']) ? (float) $node['ratingValue'] : 0;
        if ($count < 1 || $value <= 0) {
            return true;
        }
    }
    if (in_array('Review', $types, true)) {
        $rating = isset($node['reviewRating']) ? $node['reviewRating'] : array();
        $value = is_array($rating) && isset($rating['ratingValue']) ? (float) $rating['ratingValue'] : 0;
        if ($value <= 0 || empty($node['author'])) {
            return true;
        }
    }
    if (in_array('FAQPage', $types, true) && (empty($node['mainEntity']) || !is_array($node['mainEntity']))) {
        return true;
    }
    return false;
}

function scr_clean_schema_node($node, &$removed) {
    if (!is_array($node)) {
        return $node;
    }
    if (scr_schema_is_invalid($node)) {
        $removed = true;
        return null;
    }
    if (isset($node['@graph']) && is_array($node['@graph'])) {
        $graph = array();
        foreach ($node['@graph'] as $piece) {
            $kept = scr_clean_schema_node($piece, $removed);
            if ($kept !== null) {
                $graph[] = $kept;
            }
        }
        $node['@graph'] = $graph;
    }
    return $node;
}

function scr_is_private_screen() {
    if (is_search() || is_date() || is_author() || is_attachment()) {
        return true;
    }
    return function_exists('is_cart') && (is_cart() || is_checkout() || is_account_page());
}

function scr_clean_url($url) {
    if (!is_string($url) || $url === '') {
        return $url;
    }
    $parts = wp_parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) {
        return $url;
    }
    $clean = (isset($parts['scheme']) ? $parts['scheme'] : 'https') . '://' . $parts['host'];
    if (!empty($parts['port'])) {
        $clean .= ':' . $parts['port'];
    }
    $clean .= isset($parts['path']) ? $parts['path'] : '/';
    return $clean;
}

function scr_strip_invalid_schema($html) {
    if (!is_string($html) || stripos($html, 'application/ld+json') === false) {
        return $html;
    }
    return preg_replace_callback('/<script type="application\/ld\+json"[^>]*>(.*?)<\/script>/is', function ($match) {
        $data = json_decode($match[1], true);
        if (!is_array($data)) {
            return $match[0];
        }
        $removed = false;
        $data = scr_clean_schema_node($data, $removed);
        if (!$removed) {
            return $match[0];
        }
        if ($data === null || (isset($data['@graph']) && $data['@graph'] === array() && !isset($data['@type']))) {
            return '';
        }
        return '<script type="application/ld+json">' . wp_json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
    }, $html);
}

function scr_fallback_description($description) {
    $description = trim((string) $description);
    if ($description !== '' || !is_singular()) {
        return $description;
    }
    $title = trim(wp_strip_all_tags(get_the_title()));
    $name = trim(wp_strip_all_tags(get_bloginfo('name')));
    if ($title === '') {
        return $description;
    }
    if ($name === '') {
        return $title . '.';
    }
    return $title . '. ' . $name . '.';
}

add_action('template_redirect', function () {
    if (function_exists('seastake_sitemap_shutdown') || !scr_is_sitemap_request()) {
        return;
    }
    register_shutdown_function('scr_sitemap_shutdown');
}, -20);

add_action('template_redirect', function () {
    if (is_admin() || scr_is_machine_request()) {
        return;
    }
    ob_start('scr_strip_invalid_schema');
}, 2);

add_filter('wpseo_schema_graph', function ($graph) {
    if (!is_array($graph)) {
        return $graph;
    }
    $kept = array();
    foreach ($graph as $piece) {
        $removed = false;
        $next = scr_clean_schema_node($piece, $removed);
        if ($next !== null) {
            $kept[] = $next;
        }
    }
    return $kept;
}, 20);

add_filter('woocommerce_structured_data_product', function ($markup, $product) {
    if ($product instanceof WC_Product && (float) $product->get_price() > 0) {
        return $markup;
    }
    return array();
}, 20, 2);

add_filter('wpseo_robots', function ($robots) {
    if (scr_is_private_screen()) {
        return 'noindex, follow';
    }
    return $robots;
}, 30);

add_filter('rank_math/frontend/robots', function ($robots) {
    if (scr_is_private_screen() && is_array($robots)) {
        $robots['index'] = 'noindex';
        $robots['follow'] = 'follow';
    }
    return $robots;
});

add_filter('wp_robots', function ($robots) {
    if (scr_is_private_screen()) {
        $robots['noindex'] = true;
        $robots['follow'] = true;
    }
    return $robots;
});

add_filter('wp_sitemaps_add_provider', function ($provider, $name) {
    if (scr_addon_on('sitemap') && $name === 'users') {
        return false;
    }
    return $provider;
}, 10, 2);

add_filter('wp_sitemaps_posts_entry', function ($entry, $post, $post_type) {
    unset($post_type);
    if (!scr_addon_on('sitemap') || empty($entry) || !$post instanceof WP_Post) {
        return $entry;
    }
    if ((string) get_post_meta($post->ID, '_yoast_wpseo_meta-robots-noindex', true) === '1') {
        return array();
    }
    $rank = get_post_meta($post->ID, 'rank_math_robots', true);
    if ((is_array($rank) && in_array('noindex', $rank, true)) || (is_string($rank) && stripos($rank, 'noindex') !== false)) {
        return array();
    }
    if ((string) get_post_meta($post->ID, '_seopress_robots_index', true) === 'yes') {
        return array();
    }
    return $entry;
}, 10, 3);

add_filter('wpseo_canonical', 'scr_clean_url', 30);
add_filter('wpseo_opengraph_url', 'scr_clean_url', 30);
add_filter('rank_math/frontend/canonical', 'scr_clean_url', 30);
add_filter('get_canonical_url', 'scr_clean_url', 30);

add_filter('wpseo_sitemap_exclude_post', function ($exclude, $post_id) {
    if ($exclude) {
        return true;
    }
    $noindex = get_post_meta($post_id, '_yoast_wpseo_meta-robots-noindex', true);
    return (string) $noindex === '1';
}, 10, 2);

add_filter('wpseo_metadesc', 'scr_fallback_description', 30);
add_filter('rank_math/frontend/description', 'scr_fallback_description', 30);

add_action('wp_head', function () {
    if (is_admin() || !is_singular() || defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION')) {
        return;
    }
    $description = scr_fallback_description('');
    if ($description === '') {
        return;
    }
    echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
}, 1);

add_filter('robots_txt', function ($output, $public) {
    if ((string) $public === '0') {
        return $output;
    }
    if (function_exists('WC')) {
        foreach (array('Disallow: /cart/', 'Disallow: /checkout/', 'Disallow: /my-account/') as $line) {
            if (stripos($output, $line) === false) {
                $output .= "\n" . $line;
            }
        }
    }
    if (stripos($output, 'Sitemap:') === false) {
        $output .= "\nSitemap: " . home_url('/sitemap_index.xml');
    }
    return $output;
}, 20, 2);

add_filter('the_content', 'scr_add_image_dimensions', 20);

add_action('template_redirect', function () {
    if (is_admin() || !is_ssl() || scr_is_machine_request()) {
        return;
    }
    ob_start('scr_upgrade_same_site_https');
}, 3);

add_action('template_redirect', 'scr_log_404', 1);
add_action('template_redirect', 'scr_redirect_saved', 0);
add_action('template_redirect', 'scr_redirect_clean_urls', 0);
add_action('template_redirect', 'scr_redirect_attachment_page', 0);
add_filter('comment_reply_link', 'scr_clean_reply_link', 20);

add_action('init', function () {
    if (wp_next_scheduled('scr_daily_resolve')) {
        return;
    }
    wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'scr_daily_resolve');
});

add_action('scr_daily_resolve', 'scr_auto_resolve');

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('scr_daily_resolve');
});

add_action('admin_menu', function () {
    add_menu_page(
        'Search Console Resolver',
        'Search Console Resolver',
        'manage_options',
        'search-console-resolver',
        'scr_render_admin',
        'dashicons-search',
        81
    );
});

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'toplevel_page_search-console-resolver') {
        return;
    }
    wp_register_style('scr-admin', false, array(), SCR_VERSION);
    wp_enqueue_style('scr-admin');
    wp_add_inline_style('scr-admin', scr_admin_css());
});

function scr_public_post_types() {
    $types = get_post_types(array('public' => true), 'names');
    unset($types['attachment']);
    return array_values($types);
}

function scr_sitemap_loc($id) {
    $noindex = get_post_meta($id, '_yoast_wpseo_meta-robots-noindex', true);
    if ((string) $noindex === '1') {
        return '';
    }
    $link = get_permalink($id);
    return is_string($link) ? $link : '';
}

function scr_sitemap_urls($post_type) {
    if (!post_type_exists($post_type)) {
        return array();
    }
    $ids = get_posts(array(
        'post_type' => $post_type,
        'post_status' => 'publish',
        'posts_per_page' => 500,
        'fields' => 'ids',
        'orderby' => 'modified',
        'order' => 'DESC',
        'no_found_rows' => true,
        'suppress_filters' => false,
    ));
    $urls = array();
    foreach ($ids as $id) {
        $loc = scr_sitemap_loc((int) $id);
        if ($loc === '') {
            continue;
        }
        $modified = get_post_modified_time('c', true, (int) $id);
        $urls[] = array($loc, is_string($modified) ? $modified : '');
    }
    return $urls;
}

function scr_sitemap_xml($urls) {
    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    foreach ($urls as $url) {
        $xml .= '<url><loc>' . htmlspecialchars($url[0], ENT_XML1 | ENT_COMPAT, 'UTF-8') . '</loc>';
        if ($url[1] !== '') {
            $xml .= '<lastmod>' . esc_html($url[1]) . '</lastmod>';
        }
        $xml .= '</url>' . "\n";
    }
    $xml .= '</urlset>';
    return $xml;
}

function scr_fallback_sitemap() {
    $path = scr_request_path();
    if (preg_match('#/sitemap_index\.xml$#i', $path)) {
        $home = home_url('/');
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach (scr_public_post_types() as $type) {
            $file = $type . '-sitemap.xml';
            $xml .= '<sitemap><loc>' . htmlspecialchars($home . $file, ENT_XML1 | ENT_COMPAT, 'UTF-8') . '</loc></sitemap>' . "\n";
        }
        $xml .= '</sitemapindex>';
        return $xml;
    }
    if (preg_match('#/([a-z0-9_-]+)-sitemap\d*\.xml$#i', $path, $match)) {
        return scr_sitemap_xml(scr_sitemap_urls(strtolower($match[1])));
    }
    return scr_sitemap_xml(array());
}

function scr_sitemap_shutdown() {
    $error = error_get_last();
    if (!is_array($error) || !in_array($error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR), true)) {
        return;
    }
    if (!scr_is_sitemap_request() || headers_sent()) {
        return;
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        status_header(200);
        header('Content-Type: text/xml; charset=UTF-8');
    }
    echo scr_fallback_sitemap();
}

function scr_addon_on($key) {
    $addons = get_option('scr_addons', array());
    if (!is_array($addons) || !array_key_exists($key, $addons)) {
        return true;
    }
    return !empty($addons[$key]);
}

function scr_tracking_params() {
    return array('utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'utm_id', 'fbclid', 'mc_cid', 'mc_eid', '_ga', '_gl', 'msclkid', 'igshid', 'si', 'gbraid', 'wbraid');
}

function scr_redirect_key($path) {
    $path = '/' . ltrim((string) $path, '/');
    $path = untrailingslashit($path);
    return $path === '' ? '/' : $path;
}

function scr_redirect_saved() {
    if (is_admin() || wp_doing_ajax() || wp_doing_cron() || headers_sent()) {
        return;
    }
    $rules = get_option('scr_redirects', array());
    if (!is_array($rules) || $rules === array()) {
        return;
    }
    $key = scr_redirect_key(scr_request_path());
    if (empty($rules[$key]) || !scr_is_local_url($rules[$key])) {
        return;
    }
    $target_path = scr_redirect_key((string) wp_parse_url($rules[$key], PHP_URL_PATH));
    if ($target_path === $key) {
        return;
    }
    wp_safe_redirect($rules[$key], 301);
    exit;
}

function scr_redirect_clean_urls() {
    if (!scr_addon_on('clean_urls') || is_admin() || wp_doing_ajax() || wp_doing_cron()) {
        return;
    }
    $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper((string) $_SERVER['REQUEST_METHOD']) : 'GET';
    if ($method !== 'GET' || headers_sent()) {
        return;
    }
    $strip = array();
    if (isset($_GET['replytocom']) && (string) $_GET['replytocom'] !== '') {
        $strip[] = 'replytocom';
    }
    foreach (scr_tracking_params() as $param) {
        if (isset($_GET[$param])) {
            $strip[] = $param;
        }
    }
    if ($strip === array()) {
        return;
    }
    wp_safe_redirect(remove_query_arg($strip), 301);
    exit;
}

function scr_clean_reply_link($link) {
    if (!scr_addon_on('clean_urls') || !is_string($link)) {
        return $link;
    }
    return preg_replace('/href=([\'"])[^\'"]*replytocom=\d+#respond\1/i', 'href=$1#respond$1', $link);
}

function scr_redirect_attachment_page() {
    if (!scr_addon_on('attachments') || !is_attachment() || headers_sent()) {
        return;
    }
    $url = wp_get_attachment_url(get_queried_object_id());
    if (!is_string($url) || $url === '') {
        return;
    }
    wp_safe_redirect($url, 301);
    exit;
}

function scr_add_image_dimensions($content) {
    if (!is_string($content) || stripos($content, '<img') === false) {
        return $content;
    }
    $priority_allowed = scr_addon_on('images') && is_singular() && in_the_loop() && is_main_query();
    $first = true;
    return preg_replace_callback('/<img\b[^>]*>/i', function ($match) use (&$first, $priority_allowed) {
        $priority = $priority_allowed && $first;
        $first = false;
        return scr_prepare_image_tag($match[0], $priority);
    }, $content);
}

function scr_prepare_image_tag($tag, $priority) {
    $src = '';
    $id = 0;
    $has_width = preg_match('/\bwidth\s*=/i', $tag);
    $has_height = preg_match('/\bheight\s*=/i', $tag);
    $alt = null;
    if (preg_match('/\balt\s*=\s*([\'"])(.*?)\1/i', $tag, $alt_match)) {
        $alt = trim(html_entity_decode($alt_match[2], ENT_QUOTES));
    }
    $needs_alt = scr_addon_on('images') && ($alt === null || $alt === '');
    if ((!$has_width || !$has_height || $needs_alt) && preg_match('/\bsrc\s*=\s*([\'"])([^\'"]+)\1/i', $tag, $src_match)) {
        $src = html_entity_decode($src_match[2], ENT_QUOTES);
        $id = (int) attachment_url_to_postid($src);
    }
    if ($id && (!$has_width || !$has_height)) {
        $meta = wp_get_attachment_metadata($id);
        $width = isset($meta['width']) ? (int) $meta['width'] : 0;
        $height = isset($meta['height']) ? (int) $meta['height'] : 0;
        if ($width > 0 && $height > 0) {
            $extra = '';
            if (!$has_width) {
                $extra .= ' width="' . $width . '"';
            }
            if (!$has_height) {
                $extra .= ' height="' . $height . '"';
            }
            $tag = preg_replace('/<img\b/i', '<img' . $extra, $tag, 1);
        }
    }
    if (!scr_addon_on('images')) {
        return $tag;
    }
    if ($id && $needs_alt) {
        $saved = trim((string) get_post_meta($id, '_wp_attachment_image_alt', true));
        if ($saved !== '') {
            $attribute = 'alt="' . esc_attr($saved) . '"';
            if ($alt === null) {
                $tag = preg_replace('/<img\b/i', '<img ' . $attribute, $tag, 1);
            } else {
                $tag = preg_replace('/\balt\s*=\s*([\'"])(.*?)\1/i', $attribute, $tag, 1);
            }
        }
    }
    if (!preg_match('/\bloading\s*=/i', $tag)) {
        $tag = preg_replace('/<img\b/i', '<img loading="' . ($priority ? 'eager' : 'lazy') . '"', $tag, 1);
    }
    if (!preg_match('/\bdecoding\s*=/i', $tag)) {
        $tag = preg_replace('/<img\b/i', '<img decoding="async"', $tag, 1);
    }
    if ($priority && !preg_match('/\bfetchpriority\s*=/i', $tag)) {
        $tag = preg_replace('/<img\b/i', '<img fetchpriority="high"', $tag, 1);
    }
    return $tag;
}

function scr_upgrade_same_site_https($html) {
    if (!is_string($html) || !is_ssl()) {
        return $html;
    }
    $hosts = array();
    foreach (array(home_url(), site_url()) as $url) {
        $host = wp_parse_url($url, PHP_URL_HOST);
        if (is_string($host) && $host !== '') {
            $hosts[strtolower($host)] = $host;
        }
    }
    foreach ($hosts as $host) {
        $html = str_replace('http://' . $host, 'https://' . $host, $html);
    }
    return $html;
}

function scr_log_404() {
    if (!is_404() || is_admin()) {
        return;
    }
    $path = scr_request_path();
    if ($path === '' || $path === '/') {
        return;
    }
    $log = get_option('scr_404_log', array());
    if (!is_array($log)) {
        $log = array();
    }
    $kept = array();
    foreach ($log as $row) {
        if (!is_array($row) || !isset($row['path']) || $row['path'] === $path) {
            continue;
        }
        $kept[] = $row;
    }
    array_unshift($kept, array('path' => $path, 'time' => time()));
    update_option('scr_404_log', array_slice($kept, 0, 50), false);
}

function scr_word_count($html) {
    $text = trim(wp_strip_all_tags((string) $html));
    if ($text === '') {
        return 0;
    }
    $count = preg_match_all('/\S+/u', $text);
    return $count ? (int) $count : 0;
}

function scr_robots_output() {
    $output = apply_filters('robots_txt', "User-agent: *\nDisallow:\n", '1');
    return is_string($output) ? $output : '';
}

function scr_robots_blocks_site() {
    return (bool) preg_match('/^\s*Disallow:\s*\/\s*$/m', scr_robots_output());
}

function scr_robots_blocks_path($path) {
    if (scr_robots_blocks_site()) {
        return true;
    }
    $path = '/' . ltrim((string) $path, '/');
    foreach (preg_split('/\r\n|\n|\r/', scr_robots_output()) as $line) {
        if (!preg_match('/^\s*Disallow:\s*(.+)$/i', $line, $match)) {
            continue;
        }
        $rule = trim($match[1]);
        $rule = preg_replace('/\*.*$/', '', $rule);
        if (!is_string($rule) || $rule === '' || $rule === '/') {
            continue;
        }
        if (strpos($rule, '/wp-admin') === 0) {
            continue;
        }
        if (strpos($path, $rule) === 0) {
            return true;
        }
    }
    return false;
}

function scr_text_length($text) {
    $text = trim(wp_strip_all_tags((string) $text));
    return function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);
}

function scr_meta_problem($post) {
    $title = trim(wp_strip_all_tags($post->post_title));
    $stored_title = trim((string) get_post_meta($post->ID, '_yoast_wpseo_title', true));
    $rank_title = trim((string) get_post_meta($post->ID, 'rank_math_title', true));
    $shown_title = $title;
    if ($stored_title !== '' && strpos($stored_title, '%%') === false) {
        $shown_title = $stored_title;
    } elseif ($rank_title !== '' && strpos($rank_title, '%') === false) {
        $shown_title = $rank_title;
    }
    $desc = trim((string) get_post_meta($post->ID, '_yoast_wpseo_metadesc', true));
    if ($desc === '') {
        $desc = trim((string) get_post_meta($post->ID, 'rank_math_description', true));
    }
    $reasons = array();
    $title_length = scr_text_length($shown_title);
    if ($title === '') {
        $reasons[] = 'missing title';
    } elseif ($title_length > 65) {
        $reasons[] = 'title is ' . $title_length . ' characters';
    }
    $desc_length = scr_text_length($desc);
    if ($desc === '') {
        $reasons[] = 'missing meta description';
    } elseif ($desc_length < 50) {
        $reasons[] = 'description is short';
    } elseif ($desc_length > 160) {
        $reasons[] = 'description is ' . $desc_length . ' characters';
    }
    if ($reasons === array()) {
        return null;
    }
    return array(
        'title' => $title !== '' ? $title : '(no title)',
        'url' => get_permalink($post),
        'edit' => get_edit_post_link($post->ID, 'raw'),
        'note' => implode(', ', $reasons),
    );
}

function scr_link_is_live($url) {
    static $cache = array();
    $key = scr_clean_url($url);
    if (isset($cache[$key])) {
        return $cache[$key];
    }
    if (!scr_is_local_url($url)) {
        $cache[$key] = true;
        return true;
    }
    $path = trim((string) wp_parse_url($url, PHP_URL_PATH), '/');
    if ($path === '') {
        $cache[$key] = true;
        return true;
    }
    $id = url_to_postid($url);
    if ($id && get_post_status($id) === 'publish') {
        $cache[$key] = true;
        return true;
    }
    $post = get_page_by_path($path, OBJECT, scr_public_post_types());
    if ($post instanceof WP_Post && $post->post_status === 'publish') {
        $cache[$key] = true;
        return true;
    }
    $slug = basename($path);
    foreach (get_taxonomies(array('public' => true), 'names') as $taxonomy) {
        $term = get_term_by('slug', $slug, $taxonomy);
        if ($term instanceof WP_Term) {
            $cache[$key] = true;
            return true;
        }
    }
    $cache[$key] = false;
    return false;
}

function scr_scan_content() {
    $posts = get_posts(array(
        'post_type' => array('post', 'page'),
        'post_status' => 'publish',
        'posts_per_page' => 40,
        'orderby' => 'modified',
        'order' => 'DESC',
    ));
    $thin = array();
    $unlinked = array();
    $meta = array();
    $broken = array();
    $checked = 0;
    $missing_alts = 0;
    $title_map = array();
    foreach ($posts as $post) {
        $url = get_permalink($post);
        $plain_title = strtolower(trim(wp_strip_all_tags($post->post_title)));
        if ($plain_title !== '') {
            if (!isset($title_map[$plain_title])) {
                $title_map[$plain_title] = array('title' => $post->post_title, 'url' => $url, 'count' => 0);
            }
            $title_map[$plain_title]['count']++;
        }
        if (preg_match_all('/<img\b[^>]*>/i', $post->post_content, $images)) {
            foreach ($images[0] as $tag) {
                $alt = '';
                if (preg_match('/\balt\s*=\s*([\'"])(.*?)\1/i', $tag, $alt_match)) {
                    $alt = trim(html_entity_decode($alt_match[2], ENT_QUOTES));
                }
                if ($alt === '') {
                    $missing_alts++;
                }
            }
        }
        $words = scr_word_count($post->post_content);
        if ($words < 150) {
            $thin[] = array('title' => $post->post_title, 'url' => $url, 'words' => $words);
        }
        if (!preg_match('/<a\s[^>]*href\s*=/i', $post->post_content)) {
            $unlinked[] = array('title' => $post->post_title, 'url' => $url);
        }
        $problem = scr_meta_problem($post);
        if ($problem !== null && count($meta) < 20) {
            $meta[] = $problem;
        }
        if ($checked >= 40 || count($broken) >= 20 || !preg_match_all('/<a\s[^>]*href\s*=\s*([\'"])([^\'"]+)\1/i', $post->post_content, $links)) {
            continue;
        }
        foreach ($links[2] as $href) {
            if ($checked >= 40 || count($broken) >= 20) {
                break;
            }
            $href = html_entity_decode($href, ENT_QUOTES);
            if ($href === '' || $href[0] === '#' || stripos($href, 'mailto:') === 0 || stripos($href, 'tel:') === 0) {
                continue;
            }
            if (strpos($href, '//') === false) {
                $href = home_url($href[0] === '/' ? $href : '/' . $href);
            }
            if (!scr_is_local_url($href)) {
                continue;
            }
            $path = (string) wp_parse_url($href, PHP_URL_PATH);
            if (preg_match('/\.(?:jpe?g|png|gif|webp|svg|pdf|css|js|zip|mp4|xml)$/i', $path)) {
                continue;
            }
            $checked++;
            if (!scr_link_is_live($href)) {
                $broken[] = array('title' => $post->post_title, 'url' => $url, 'target' => scr_clean_url($href));
            }
        }
    }
    $duplicates = array();
    foreach ($title_map as $row) {
        if ($row['count'] > 1 && count($duplicates) < 15) {
            $duplicates[] = $row;
        }
    }
    return array(
        'thin' => $thin,
        'unlinked' => $unlinked,
        'meta' => $meta,
        'broken' => $broken,
        'missing_alts' => $missing_alts,
        'duplicates' => $duplicates,
    );
}

function scr_find_locked_pages() {
    global $wpdb;
    $rows = $wpdb->get_results("SELECT ID, post_title, post_status FROM {$wpdb->posts} WHERE post_password <> '' OR post_status = 'private' ORDER BY post_modified DESC LIMIT 20");
    $items = array();
    foreach ($rows as $row) {
        $items[] = array(
            'title' => $row->post_title,
            'url' => get_permalink((int) $row->ID),
            'status' => $row->post_status,
        );
    }
    return $items;
}

function scr_find_noindex_pages() {
    $posts = get_posts(array(
        'post_type' => 'any',
        'post_status' => 'publish',
        'posts_per_page' => 30,
        'meta_query' => array(
            'relation' => 'OR',
            array('key' => '_yoast_wpseo_meta-robots-noindex', 'value' => '1'),
            array('key' => 'rank_math_robots', 'value' => 'noindex', 'compare' => 'LIKE'),
        ),
    ));
    $items = array();
    foreach ($posts as $post) {
        $items[] = array('title' => $post->post_title, 'url' => get_permalink($post));
    }
    return $items;
}

function scr_find_php_uploads() {
    $upload = wp_get_upload_dir();
    if (empty($upload['basedir']) || !is_dir($upload['basedir'])) {
        return array();
    }
    $found = array();
    $seen = 0;
    try {
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($upload['basedir'], FilesystemIterator::SKIP_DOTS));
        foreach ($files as $file) {
            $seen++;
            if ($seen > 4000 || count($found) >= 20) {
                break;
            }
            if (strtolower($file->getExtension()) === 'php') {
                $found[] = $file->getPathname();
            }
        }
    } catch (Exception $error) {
        return array();
    }
    return $found;
}

function scr_find_new_admins() {
    $users = get_users(array(
        'role' => 'administrator',
        'number' => 10,
        'fields' => array('ID', 'user_login', 'user_registered'),
        'date_query' => array(array(
            'after' => gmdate('Y-m-d H:i:s', time() - 14 * DAY_IN_SECONDS),
            'inclusive' => true,
        )),
    ));
    $items = array();
    foreach ($users as $user) {
        $items[] = array(
            'login' => $user->user_login,
            'registered' => $user->user_registered,
        );
    }
    return $items;
}

function scr_mask_id($id) {
    $id = trim((string) $id);
    if (strlen($id) <= 12) {
        return $id;
    }
    return substr($id, 0, 6) . '…' . substr($id, -4);
}

function scr_add_verification(&$found, $source, $id) {
    $id = trim(wp_strip_all_tags((string) $id));
    if ($id === '') {
        return;
    }
    foreach ($found as $row) {
        if ($row['id'] === $id) {
            return;
        }
    }
    $found[] = array('source' => $source, 'id' => $id);
}

function scr_verification_from_options() {
    $found = array();
    $yoast = get_option('wpseo');
    if (is_array($yoast) && !empty($yoast['googleverify'])) {
        scr_add_verification($found, 'Yoast', $yoast['googleverify']);
    }
    $rank = get_option('rank-math-options-general');
    if (is_array($rank)) {
        foreach (array('google_verify', 'google-site-verification') as $key) {
            if (!empty($rank[$key])) {
                scr_add_verification($found, 'Rank Math', $rank[$key]);
            }
        }
    }
    foreach (array(
        'googlesitekit_site_verification_meta' => 'Site Kit',
        'googlesitekit_verification_tag' => 'Site Kit',
        'google_site_verification' => 'Verification option',
    ) as $option => $source) {
        $value = get_option($option);
        if (is_string($value)) {
            scr_add_verification($found, $source, $value);
        }
    }
    return $found;
}

function scr_find_verification() {
    $cached = get_transient('scr_gsc_tag_v14');
    if ($cached === 'none') {
        return array();
    }
    if (is_array($cached)) {
        return $cached;
    }
    $found = scr_verification_from_options();
    $response = wp_remote_get(home_url('/'), array('timeout' => 8, 'redirection' => 3));
    $html = is_wp_error($response) ? '' : (string) wp_remote_retrieve_body($response);
    if (preg_match_all('/<meta[^>]+name=["\']google-site-verification["\'][^>]*>/i', $html, $tags)) {
        foreach ($tags[0] as $tag) {
            if (preg_match('/content=["\']([^"\']+)["\']/i', $tag, $content)) {
                scr_add_verification($found, 'Homepage meta tag', $content[1]);
            }
        }
    }
    if (preg_match_all('/<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']google-site-verification["\'][^>]*>/i', $html, $reverse)) {
        foreach ($reverse[1] as $content) {
            scr_add_verification($found, 'Homepage meta tag', $content);
        }
    }
    set_transient('scr_gsc_tag_v14', $found === array() ? 'none' : $found, 12 * HOUR_IN_SECONDS);
    return $found;
}

function scr_auto_resolve() {
    $tags = scr_find_verification();
    if ($tags !== array()) {
        delete_transient('scr_report_v16');
        scr_collect_report();
        update_option('scr_last_auto_run', time(), false);
        update_option('scr_verified_property', $tags, false);
    }
    $connection = scr_google_connection();
    if ($connection['token'] === '') {
        return;
    }
    set_transient('scr_gsc_report_v18', scr_sync_google(false, false), 6 * HOUR_IN_SECONDS);
}

function scr_match_404s($missing) {
    $items = array();
    if (!is_array($missing)) {
        return $items;
    }
    $types = array('post', 'page');
    if (post_type_exists('product')) {
        $types[] = 'product';
    }
    $ids = get_posts(array(
        'post_type' => $types,
        'post_status' => 'publish',
        'posts_per_page' => 200,
        'fields' => 'ids',
        'no_found_rows' => true,
        'orderby' => 'modified',
        'order' => 'DESC',
    ));
    $pages = array();
    foreach ($ids as $id) {
        $post = get_post((int) $id);
        if (!$post instanceof WP_Post) {
            continue;
        }
        $pages[] = array('slug' => $post->post_name, 'url' => get_permalink($post), 'title' => $post->post_title);
    }
    foreach (array_slice($missing, 0, 20) as $row) {
        if (!is_array($row) || empty($row['path'])) {
            continue;
        }
        $needle = strtolower(basename(trim((string) $row['path'], '/')));
        $best = null;
        $best_score = 0;
        foreach ($pages as $page) {
            $score = 0;
            similar_text($needle, strtolower($page['slug']), $score);
            if ($score > $best_score) {
                $best_score = $score;
                $best = $page;
            }
        }
        $items[] = array(
            'path' => $row['path'],
            'url' => isset($row['url']) ? $row['url'] : home_url($row['path']),
            'suggestion' => ($best && $best_score >= 55) ? $best['url'] : '',
            'suggestion_title' => ($best && $best_score >= 55) ? $best['title'] : '',
        );
    }
    return $items;
}

function scr_find_heavy_images() {
    $ids = get_posts(array(
        'post_type' => 'attachment',
        'post_status' => 'inherit',
        'post_mime_type' => 'image',
        'posts_per_page' => 80,
        'orderby' => 'date',
        'order' => 'DESC',
        'fields' => 'ids',
        'no_found_rows' => true,
    ));
    $heavy = array();
    foreach ($ids as $id) {
        $file = get_attached_file((int) $id);
        $bytes = is_string($file) && is_file($file) ? (int) filesize($file) : 0;
        if ($bytes < 400000) {
            continue;
        }
        $url = wp_get_attachment_url((int) $id);
        $heavy[] = array(
            'title' => get_the_title((int) $id),
            'url' => is_string($url) ? $url : '',
            'note' => size_format($bytes),
        );
        if (count($heavy) >= 15) {
            break;
        }
    }
    return $heavy;
}

function scr_redirect_loops() {
    $rules = get_option('scr_redirects', array());
    if (!is_array($rules)) {
        return array();
    }
    $loops = array();
    foreach ($rules as $from => $to) {
        $target = scr_redirect_key((string) wp_parse_url((string) $to, PHP_URL_PATH));
        if (!isset($rules[$target])) {
            continue;
        }
        $back = scr_redirect_key((string) wp_parse_url((string) $rules[$target], PHP_URL_PATH));
        if ($back === scr_redirect_key((string) $from)) {
            $loops[] = scr_redirect_key((string) $from) . ' ↔ ' . $target;
        }
    }
    return array_values(array_unique($loops));
}

function scr_active_seo_plugins() {
    $map = array(
        'wordpress-seo/' => 'Yoast',
        'wordpress-seo-premium/' => 'Yoast',
        'seo-by-rank-math/' => 'Rank Math',
        'seo-by-rank-math-pro/' => 'Rank Math',
        'all-in-one-seo-pack/' => 'All in One SEO',
        'all-in-one-seo-pack-pro/' => 'All in One SEO',
        'wp-seopress/' => 'SEOPress',
        'wp-seopress-pro/' => 'SEOPress',
    );
    $active = array_map('strval', (array) get_option('active_plugins', array()));
    if (is_multisite()) {
        $network = get_site_option('active_sitewide_plugins', array());
        if (is_array($network)) {
            $active = array_merge($active, array_map('strval', array_keys($network)));
        }
    }
    $found = array();
    foreach ($active as $plugin) {
        foreach ($map as $needle => $label) {
            if (strpos($plugin, $needle) === 0) {
                $found[$label] = $label;
            }
        }
    }
    return array_values($found);
}

function scr_theme_has_viewport() {
    if (function_exists('wp_is_block_theme') && wp_is_block_theme()) {
        return true;
    }
    $header = get_template_directory() . '/header.php';
    if (!is_readable($header)) {
        return false;
    }
    $contents = file_get_contents($header);
    return is_string($contents) && stripos($contents, 'viewport') !== false;
}

function scr_site_factors($content, $heavy) {
    $factors = array();
    $visible = (string) get_option('blog_public') !== '0';
    $factors[] = array(
        'label' => 'Search visibility',
        'state' => $visible ? 'good' : 'warn',
        'detail' => $visible ? 'Search engines are allowed to index this site.' : 'Settings → Reading is set to discourage search engines.',
    );
    $https = stripos(home_url(), 'https://') === 0;
    $factors[] = array(
        'label' => 'HTTPS',
        'state' => $https ? 'good' : 'warn',
        'detail' => $https ? 'The site address uses HTTPS.' : 'The site address still starts with http.',
    );
    $home_host = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));
    $site_host = strtolower((string) wp_parse_url(site_url(), PHP_URL_HOST));
    $hosts_match = $home_host !== '' && $home_host === $site_host;
    $factors[] = array(
        'label' => 'Address host',
        'state' => $hosts_match ? 'good' : 'warn',
        'detail' => $hosts_match ? 'The WordPress address and the site address use the same host.' : 'The WordPress address and the site address use different hosts. Leave the redirect to your host so it cannot loop.',
    );
    $plain = trim((string) get_option('permalink_structure')) === '';
    $factors[] = array(
        'label' => 'Permalinks',
        'state' => $plain ? 'warn' : 'good',
        'detail' => $plain ? 'Permalinks are still plain. Choose Post name under Settings → Permalinks.' : 'Permalinks use a named structure.',
    );
    $sitemaps = !function_exists('wp_sitemaps_get_server') || wp_sitemaps_get_server()->sitemaps_enabled();
    $factors[] = array(
        'label' => 'Core sitemap',
        'state' => $sitemaps ? 'good' : 'warn',
        'detail' => $sitemaps ? 'The WordPress sitemap can be served. Noindex posts and author archives stay out of it while that add-on is on.' : 'The WordPress sitemap is switched off. Turn search visibility on, or use the sitemap from your SEO plugin.',
    );
    $seo = scr_active_seo_plugins();
    $factors[] = array(
        'label' => 'SEO plugin',
        'state' => count($seo) > 1 ? 'warn' : 'good',
        'detail' => $seo === array() ? 'No supported SEO plugin is active, so this plugin prints a basic description only where one is missing.' : (count($seo) > 1 ? 'More than one SEO plugin is active: ' . implode(', ', $seo) . '. Keep one.' : $seo[0] . ' is the active SEO plugin. This plugin does not replace its titles.'),
    );
    $viewport = scr_theme_has_viewport();
    $factors[] = array(
        'label' => 'Mobile viewport',
        'state' => $viewport ? 'good' : 'warn',
        'detail' => $viewport ? 'The theme provides a mobile viewport.' : 'The theme header does not include a viewport tag. Add one in the theme before judging mobile issues.',
    );
    $alts = isset($content['missing_alts']) ? (int) $content['missing_alts'] : 0;
    $factors[] = array(
        'label' => 'Image alt text',
        'state' => $alts > 0 ? 'warn' : 'good',
        'detail' => $alts > 0 ? $alts . ' image(s) in the newest pages have no alt text. Write a real description in the Media Library.' : 'The newest pages that were checked have alt text on their images.',
    );
    $dupes = isset($content['duplicates']) && is_array($content['duplicates']) ? count($content['duplicates']) : 0;
    $factors[] = array(
        'label' => 'Duplicate titles',
        'state' => $dupes > 0 ? 'warn' : 'good',
        'detail' => $dupes > 0 ? $dupes . ' title(s) are shared by more than one recent page.' : 'The newest pages that were checked do not share a title.',
    );
    $heavy_count = is_array($heavy) ? count($heavy) : 0;
    $factors[] = array(
        'label' => 'Large images',
        'state' => $heavy_count > 0 ? 'warn' : 'good',
        'detail' => $heavy_count > 0 ? $heavy_count . ' recent image file(s) are over 400 KB. Compress those originals in the Media Library.' : 'None of the newest 80 images is over 400 KB.',
    );
    $loops = scr_redirect_loops();
    $factors[] = array(
        'label' => 'Saved redirects',
        'state' => $loops === array() ? 'good' : 'warn',
        'detail' => $loops === array() ? 'Saved redirects do not point at each other.' : 'These redirects point at each other: ' . implode(', ', $loops) . '.',
    );
    return $factors;
}

function scr_check_sitemap() {
    $url = home_url('/sitemap_index.xml');
    $response = wp_remote_get($url, array('timeout' => 8, 'redirection' => 3));
    if (is_wp_error($response)) {
        return array('url' => $url, 'code' => 0, 'xml' => false);
    }
    $body = (string) wp_remote_retrieve_body($response);
    $code = (int) wp_remote_retrieve_response_code($response);
    $xml = $code === 200 && (stripos($body, '<urlset') !== false || stripos($body, '<sitemapindex') !== false);
    return array('url' => $url, 'code' => $code, 'xml' => $xml);
}

function scr_priority_actions($report) {
    $actions = array();
    if (isset($report['visible']) && empty($report['visible'])) {
        $actions[] = 'Settings → Reading is hiding this site from search engines. Uncheck “Discourage search engines from indexing this site”.';
    }
    if (!empty($report['robots_block'])) {
        $actions[] = 'robots.txt blocks the whole site. Remove the Disallow: / line and leave /wp-admin/ blocked.';
    }
    if (empty($report['https'])) {
        $actions[] = 'Turn on the SSL certificate, then set both addresses in Settings → General to https.';
    }
    if (!empty($report['factors']) && is_array($report['factors'])) {
        foreach ($report['factors'] as $factor) {
            if (!is_array($factor) || empty($factor['state']) || $factor['state'] !== 'warn') {
                continue;
            }
            if (in_array($factor['label'], array('Search visibility', 'HTTPS'), true)) {
                continue;
            }
            $actions[] = $factor['label'] . ': ' . $factor['detail'];
        }
    }
    if (empty($report['sitemap']['xml'])) {
        $code = isset($report['sitemap']['code']) ? (int) $report['sitemap']['code'] : 0;
        $actions[] = 'The sitemap did not return XML (HTTP ' . $code . '). Open it and fix that before you resubmit it in Search Console.';
    }
    if (!empty($report['php'])) {
        $actions[] = count($report['php']) . ' PHP file(s) are inside the uploads folder. Review each one, then request a security review in Search Console.';
    }
    if (!empty($report['admins'])) {
        $actions[] = count($report['admins']) . ' administrator account(s) were created in the last 14 days. Confirm that you created each one.';
    }
    if (!empty($report['thin'])) {
        $actions[] = count($report['thin']) . ' recent page(s) have under 150 words. Add real text on those pages, then click Validate fix for Crawled - currently not indexed.';
    }
    if (!empty($report['meta'])) {
        $actions[] = count($report['meta']) . ' recent page(s) have a title or description that is missing or the wrong length. Edit them in Yoast or Rank Math.';
    }
    if (!empty($report['broken'])) {
        $actions[] = count($report['broken']) . ' internal link(s) point at a page this site cannot find. Edit the source page, or add one redirect when you know the replacement.';
    }
    $matched = 0;
    if (!empty($report['matches']) && is_array($report['matches'])) {
        foreach ($report['matches'] as $row) {
            if (!empty($row['suggestion'])) {
                $matched++;
            }
        }
    }
    if ($matched > 0) {
        $actions[] = $matched . ' recent 404(s) look similar to a live page. Copy that live URL into your redirect plugin. Leave a 404 alone when there is no real replacement.';
    }
    if (!empty($report['noindex'])) {
        $actions[] = count($report['noindex']) . ' published item(s) are set to noindex. Allow indexing only for pages you want Google to show.';
    }
    return array_slice($actions, 0, 8);
}

function scr_collect_report() {
    $cached = get_transient('scr_report_v19');
    if (is_array($cached)) {
        return $cached;
    }
    $content = scr_scan_content();
    $missing = get_option('scr_404_log', array());
    $heavy = scr_find_heavy_images();
    $report = array(
        'thin' => $content['thin'],
        'unlinked' => $content['unlinked'],
        'meta' => $content['meta'],
        'broken' => $content['broken'],
        'missing_alts' => isset($content['missing_alts']) ? (int) $content['missing_alts'] : 0,
        'duplicates' => isset($content['duplicates']) ? $content['duplicates'] : array(),
        'heavy' => $heavy,
        'locked' => scr_find_locked_pages(),
        'noindex' => scr_find_noindex_pages(),
        'missing' => is_array($missing) ? $missing : array(),
        'matches' => scr_match_404s(is_array($missing) ? $missing : array()),
        'sitemap' => scr_check_sitemap(),
        'https' => stripos(home_url(), 'https://') === 0,
        'visible' => (string) get_option('blog_public') !== '0',
        'robots_block' => scr_robots_blocks_site(),
        'php' => scr_find_php_uploads(),
        'admins' => scr_find_new_admins(),
        'factors' => scr_site_factors($content, $heavy),
    );
    set_transient('scr_report_v19', $report, 15 * MINUTE_IN_SECONDS);
    return $report;
}

function scr_is_local_url($url) {
    $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
    $home = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));
    if ($host === '' || $home === '') {
        return false;
    }
    return $host === $home || $host === 'www.' . $home || 'www.' . $host === $home;
}

function scr_absolute_url($location, $base) {
    if (!is_string($location) || $location === '') {
        return '';
    }
    if (preg_match('#^https?://#i', $location)) {
        return $location;
    }
    $parts = wp_parse_url($base);
    if (!is_array($parts) || empty($parts['host'])) {
        return $location;
    }
    $origin = (isset($parts['scheme']) ? $parts['scheme'] : 'https') . '://' . $parts['host'];
    if (strpos($location, '//') === 0) {
        return (isset($parts['scheme']) ? $parts['scheme'] : 'https') . ':' . $location;
    }
    if (isset($location[0]) && $location[0] === '/') {
        return $origin . $location;
    }
    $path = isset($parts['path']) ? $parts['path'] : '/';
    return $origin . trailingslashit(dirname($path)) . $location;
}

function scr_follow_url($url) {
    $seen = array();
    $current = $url;
    $chain = array();
    $code = 0;
    $body = '';
    $headers = array();
    for ($hop = 0; $hop < 5; $hop++) {
        if (isset($seen[$current])) {
            return array('code' => $code, 'body' => $body, 'headers' => $headers, 'chain' => $chain, 'loop' => true, 'final' => $current);
        }
        if (!scr_is_local_url($current)) {
            return array('code' => 0, 'body' => '', 'headers' => array(), 'chain' => $chain, 'loop' => false, 'final' => $current, 'offsite' => true);
        }
        $seen[$current] = true;
        $response = wp_remote_get($current, array('timeout' => 8, 'redirection' => 0, 'sslverify' => true));
        if (is_wp_error($response)) {
            return array('code' => 0, 'body' => '', 'headers' => array(), 'chain' => $chain, 'loop' => false, 'final' => $current, 'error' => $response->get_error_message());
        }
        $code = (int) wp_remote_retrieve_response_code($response);
        $headers = wp_remote_retrieve_headers($response);
        $body = (string) wp_remote_retrieve_body($response);
        $chain[] = array('url' => $current, 'code' => $code);
        if ($code < 300 || $code >= 400) {
            break;
        }
        $location = wp_remote_retrieve_header($response, 'location');
        $location = is_array($location) ? end($location) : $location;
        $next = scr_absolute_url((string) $location, $current);
        if ($next === '') {
            break;
        }
        $current = $next;
    }
    return array('code' => $code, 'body' => $body, 'headers' => $headers, 'chain' => $chain, 'loop' => false, 'final' => $current);
}

function scr_body_canonical($body) {
    if (!preg_match('/<link[^>]+rel=["\']canonical["\'][^>]*>/i', $body, $tag)) {
        return '';
    }
    if (preg_match('/href=["\']([^"\']+)["\']/i', $tag[0], $href)) {
        return $href[1];
    }
    return '';
}

function scr_body_noindex($body, $headers) {
    $robots = '';
    if (is_array($headers) || $headers instanceof ArrayAccess) {
        $robots = isset($headers['x-robots-tag']) ? (string) $headers['x-robots-tag'] : '';
    }
    if (stripos($robots, 'noindex') !== false) {
        return true;
    }
    return (bool) preg_match('/<meta[^>]+name=["\']robots["\'][^>]*content=["\'][^"\']*noindex/i', $body);
}

function scr_breadcrumb_gaps($body) {
    $gaps = 0;
    if (!preg_match_all('/<script type="application\/ld\+json"[^>]*>(.*?)<\/script>/is', $body, $scripts)) {
        return 0;
    }
    foreach ($scripts[1] as $json) {
        $data = json_decode($json, true);
        if (!is_array($data)) {
            continue;
        }
        $nodes = isset($data['@graph']) && is_array($data['@graph']) ? $data['@graph'] : array($data);
        foreach ($nodes as $node) {
            if (!is_array($node) || !in_array('BreadcrumbList', scr_schema_type_list($node), true)) {
                continue;
            }
            $items = isset($node['itemListElement']) && is_array($node['itemListElement']) ? $node['itemListElement'] : array();
            foreach ($items as $item) {
                if (!is_array($item) || empty($item['item'])) {
                    $gaps++;
                }
            }
        }
    }
    return $gaps;
}

function scr_linked_from_content($path) {
    global $wpdb;
    $like = '%' . $wpdb->esc_like($path) . '%';
    $found = $wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_content LIKE %s LIMIT 1", $like));
    return (bool) $found;
}

function scr_check_url($url) {
    $url = esc_url_raw(trim($url));
    if ($url === '' || !scr_is_local_url($url)) {
        return array('url' => $url, 'notes' => array('Use a URL from this site.'));
    }
    $result = scr_follow_url($url);
    $notes = array();
    $path = (string) wp_parse_url($url, PHP_URL_PATH);
    $hops = max(0, count($result['chain']) - 1);
    if (!empty($result['error'])) {
        $notes[] = 'The site could not open this URL. ' . $result['error'] . ' If Google reports a crawl anomaly, check hosting uptime.';
    }
    if (!empty($result['offsite'])) {
        $notes[] = 'The redirect leaves this domain. Confirm that destination yourself.';
    }
    if (!empty($result['loop']) || $hops > 3) {
        $notes[] = 'Redirect error: the chain loops or is longer than three hops.';
    } elseif ($hops > 0) {
        $notes[] = 'Page with redirect. Destination: ' . $result['final'] . '. Keep the original URL out of the sitemap.';
    }
    $code = (int) $result['code'];
    if ($code === 401) {
        $notes[] = 'Blocked due to unauthorized request (401). Make the page public, or leave it out of the index.';
    } elseif ($code === 403) {
        $notes[] = 'Blocked due to access forbidden (403). Make the page public, or leave it out of the index.';
    } elseif ($code === 404) {
        $notes[] = 'Not found (404). Add a redirect only if you know the replacement page. Do not publish an empty page just to hide the 404.';
    } elseif ($code >= 500) {
        $notes[] = 'Server error (' . $code . '). Read the host PHP error log. This plugin keeps a fallback sitemap, and it cannot repair the server.';
    } elseif ($code === 200) {
        $words = scr_word_count($result['body']);
        if ($words < 30) {
            $notes[] = 'Soft 404 risk: the page returns 200 with almost no text. Add useful content or unpublish it.';
        } elseif ($words < 150) {
            $notes[] = 'Crawled - currently not indexed is likely while this page has only ' . $words . ' words. Add a useful explanation. The plugin will not write that text.';
        }
        if (scr_body_noindex($result['body'], $result['headers'])) {
            $notes[] = 'Excluded by noindex. Remove that tag only if this page should be indexed.';
        }
        $canonical = scr_body_canonical($result['body']);
        if ($canonical !== '') {
            $canon_path = (string) wp_parse_url($canonical, PHP_URL_PATH);
            if (untrailingslashit($canon_path) !== untrailingslashit($path)) {
                $notes[] = 'Alternate page with a proper canonical. Google should index ' . $canonical . '. This is normal when that canonical is the page you want.';
            }
        }
        $gaps = scr_breadcrumb_gaps($result['body']);
        if ($gaps > 0) {
            $notes[] = 'BreadcrumbList has ' . $gaps . ' item(s) without a URL.';
        }
        if (!scr_linked_from_content($path)) {
            $notes[] = 'Discovered - currently not indexed can linger because no published page links to this URL. Add a normal link from a related page.';
        }
    }
    if (scr_robots_blocks_path($path)) {
        $notes[] = 'Blocked by robots.txt. Do not remove the block on /wp-admin/. Remove a rule only if it blocks a public page you want crawled.';
    }
    if ($notes === array()) {
        $notes[] = 'No technical fault showed up on this URL. If Google has not indexed it yet, wait for a recrawl.';
    }
    return array('url' => $url, 'code' => $code, 'notes' => $notes);
}

function scr_issue_rows($report) {
    $thin = count($report['thin']);
    $missing = is_array($report['missing']) ? count($report['missing']) : 0;
    $locked = count($report['locked']);
    $noindex = count($report['noindex']);
    $php = count($report['php']);
    $admins = count($report['admins']);
    return array(
        array('Page indexing', 'Crawled - currently not indexed', $thin ? 'Needs you' : 'Fixed on the site', $thin ? $thin . ' of the newest pages have under 150 words. Follow the steps below.' : 'The newest pages that were checked have enough text. Google can still wait before indexing.', array(
            'Open each page listed under Pages that need text.',
            'Add a real heading, a few paragraphs about that page, and one link to a related page on this site.',
            'Click Update.',
            'In Search Console, open Page indexing, then Crawled - currently not indexed, and click Validate fix.',
        )),
        array('Page indexing', 'Discovered - currently not indexed', 'Needs you', 'Paste each URL into the checker below, then follow the steps.', array(
            'Copy the URL from Search Console and paste it into Check URLs from Search Console on this screen.',
            'If the result says no published page links to it, add a normal text link from a related page or from the menu.',
            'Confirm the URL appears in the sitemap.',
            'In Search Console, open Discovered - currently not indexed and click Validate fix.',
        )),
        array('Page indexing', 'Blocked by robots.txt', $report['robots_block'] ? 'Needs you' : 'Fixed on the site', $report['robots_block'] ? 'robots.txt blocks the whole site. Follow the steps below.' : 'robots.txt does not block the whole site. /wp-admin/ stays blocked.', array(
            'Go to Settings, then Reading, and leave “Discourage search engines from indexing this site” unchecked.',
            'Open robots.txt on the live site. Remove a line that says Disallow: / . Leave Disallow: /wp-admin/ in place.',
            'Reload robots.txt and confirm the public pages are allowed.',
            'In Search Console, open Blocked by robots.txt and click Validate fix.',
        )),
        array('Page indexing', 'Blocked due to unauthorized request (401)', $locked ? 'Needs you' : 'Fixed on the site', $locked ? $locked . ' password-protected or private items were found. Follow the steps below.' : 'No password-protected or private items were found in the latest check.', array(
            'Open each item listed under Password-protected or private items.',
            'In the editor, set Visibility to Public and remove the password if visitors should see the page.',
            'Click Update. Leave it private if it should stay out of Google.',
            'In Search Console, open Blocked due to unauthorized request (401) and click Validate fix.',
        )),
        array('Page indexing', 'Blocked due to access forbidden (403)', 'Needs you', 'Paste the URL below, then follow the steps.', array(
            'Paste the URL from Search Console into the checker on this page and note the status.',
            'In WordPress, check a membership plugin or a security rule that blocks visitors from that page.',
            'In hosting, allow normal visitors and Googlebot for that path if the page is meant to be public.',
            'Open the URL in a private browser window and confirm it loads.',
            'In Search Console, open Blocked due to access forbidden (403) and click Validate fix.',
        )),
        array('Page indexing', 'Not found (404)', $missing ? 'Needs you' : 'Fixed on the site', $missing ? $missing . ' recent missing URLs were recorded. Follow the steps below.' : 'No recent 404s have been recorded.', array(
            'Open each path listed under Recent 404s.',
            'If the page moved, add one redirect in Yoast or Rank Math from the old path to the real page.',
            'Skip the URL when there is no real replacement.',
            'In Search Console, open Not found (404) and click Validate fix.',
        )),
        array('Page indexing', 'Soft 404', $thin ? 'Needs you' : 'Fixed on the site', $thin ? 'Thin published pages can look like soft 404s. Follow the steps below.' : 'No very thin page was found in the newest sample.', array(
            'Open each page listed under Pages that need text.',
            'Add real content, or move the page to Draft if it should not be a result.',
            'Click Update.',
            'In Search Console, open Soft 404 and click Validate fix.',
        )),
        array('Page indexing', 'Page with redirect', 'Fixed on the site', 'Redirecting URLs are left out of the fallback sitemap. Paste a URL to see its destination.', array()),
        array('Page indexing', 'Redirect error', 'Needs you', 'Paste the URL below. A loop, or a chain longer than three hops, is reported. Follow the steps.', array(
            'Paste the URL into the checker and read whether it reports a loop or a long chain.',
            'In Yoast or Rank Math, open that redirect and point it once, directly, at the final page.',
            'Remove the extra hops.',
            'Request the URL again and confirm it lands in one hop.',
            'In Search Console, open Redirect error and click Validate fix.',
        )),
        array('Page indexing', 'Excluded by noindex tag', $noindex ? 'Needs you' : 'Fixed on the site', $noindex ? $noindex . ' published items are noindex. Follow the steps below.' : 'No extra noindex items were found. Utility pages stay noindex on purpose.', array(
            'Open each item listed under Published items set to noindex.',
            'In Yoast or Rank Math, set that page to allow search engines to show it.',
            'Leave search, author, date, and attachment pages set to noindex.',
            'Click Update.',
            'In Search Console, open Excluded by noindex tag and click Validate fix.',
        )),
        array('Page indexing', 'Duplicate without user-selected canonical', 'Fixed on the site', 'Tracking parameters are removed from the canonical URL. WordPress, Yoast, or Rank Math prints one canonical.', array()),
        array('Page indexing', 'Alternate page with proper canonical tag', 'Not an error', 'A valid alternate that points at the main URL does not need a fix. Index the canonical page.', array()),
        array('Server errors', 'Server error (5xx)', 'Needs you', 'A crashed sitemap is replaced automatically. Any other 5xx follows the steps below.', array(
            'Open the hosting error log and find the time shown in Search Console.',
            'Fix the plugin, theme, or PHP error named in that log.',
            'Reload the URL and confirm it loads.',
            'In Search Console, open Server error (5xx) and click Validate fix.',
        )),
        array('Server errors', 'Crawl anomaly', 'Needs you', 'This is a temporary connection failure. Follow the steps below.', array(
            'Check hosting uptime for the date in the Search Console report.',
            'Open the URL in a browser and confirm the site is up.',
            'In Search Console, open Crawl anomaly and click Validate fix.',
        )),
        array('Experience', 'LCP', 'Needs you', 'A slow main image is the usual cause. Follow the steps below.', array(
            'Open PageSpeed Insights for the slow URL from Search Console.',
            'Compress the largest image above the fold and upload the smaller file in the Media Library.',
            'Keep the image width and height.',
            'In Search Console, open Core Web Vitals, then the LCP issue, and click Validate fix.',
        )),
        array('Experience', 'INP', 'Needs you', 'Slow taps usually come from heavy scripts. Follow the steps below.', array(
            'Open PageSpeed Insights for the slow URL and note the long script.',
            'Turn off the extra plugin that adds that script, if you do not need it.',
            'In Search Console, open the INP issue and click Validate fix.',
        )),
        array('Experience', 'CLS', 'Fixed on the site', 'Content images from the Media Library receive width and height when those attributes are missing.', array()),
        array('Experience', 'HTTPS', $report['https'] ? 'Fixed on the site' : 'Needs you', $report['https'] ? 'The site address uses HTTPS. Same-site http image and file URLs are rewritten to https on HTTPS pages.' : 'The site address still starts with http. Follow the steps below.', array(
            'Turn on the SSL certificate in hosting.',
            'In WordPress, go to Settings, then General. Set both WordPress Address and Site Address to https.',
            'Save the settings and open the homepage on https.',
            'In Search Console, open the HTTPS issue and click Validate fix.',
        )),
        array('Site factors', 'Search visibility', (isset($report['visible']) && empty($report['visible'])) ? 'Needs you' : 'Fixed on the site', (isset($report['visible']) && empty($report['visible'])) ? 'This site is set to discourage search engines.' : 'Search engines are allowed to index this site.', array(
            'Go to Settings, then Reading.',
            'Uncheck “Discourage search engines from indexing this site”.',
            'Save the settings and reload robots.txt.',
        )),
        array('Site factors', 'Large images', !empty($report['heavy']) ? 'Needs you' : 'Fixed on the site', !empty($report['heavy']) ? count($report['heavy']) . ' recent image file(s) are over 400 KB. Compress the originals in the Media Library and keep the same file name.' : 'None of the newest 80 images is over 400 KB.', array()),
        array('Site factors', 'Duplicate titles', !empty($report['duplicates']) ? 'Needs you' : 'Fixed on the site', !empty($report['duplicates']) ? count($report['duplicates']) . ' title(s) are shared by more than one recent page. Give each page its own title.' : 'The newest pages that were checked do not share a title.', array()),
        array('Site factors', 'Missing alt text', !empty($report['missing_alts']) ? 'Needs you' : 'Fixed on the site', !empty($report['missing_alts']) ? (int) $report['missing_alts'] . ' image(s) in the newest pages have no alt text. Write that text on the Media Library file.' : 'The newest pages that were checked have alt text on their images.', array()),
        array('Structured data', 'Invalid schema', 'Fixed on the site', 'Product schema without a price, review schema without a rating, and FAQ schema without questions are removed. A pasted URL also reports breadcrumb items that have no URL.', array()),
        array('Security and manual actions', 'Manual actions', 'Needs you', 'A person has to answer a manual action in Search Console. Follow the steps below.', array(
            'In Search Console, open Security and Manual Actions, then Manual actions, and read the exact reason.',
            'Edit the pages named in that notice and remove the problem Google described.',
            'Click Request review and write what you changed.',
        )),
        array('Security and manual actions', 'Security issues', ($php || $admins) ? 'Needs you' : 'Fixed on the site', ($php || $admins) ? 'Review the PHP files or new administrator accounts listed below, then follow the steps.' : 'No PHP file in uploads, and no administrator account created in the last 14 days, showed up in this check.', array(
            'If PHP files are listed below, delete those files from wp-content/uploads in the hosting file manager after you confirm they are not yours.',
            'If a new administrator is listed and you did not create that account, open Users, delete that user, and change your own password.',
            'In Search Console, open Security issues and click Request review after the site is clean.',
        )),
    );
}

function scr_render_url_list($rows) {
    if (!is_array($rows) || $rows === array()) {
        echo '<p>None in this check.</p>';
        return;
    }
    echo '<ul>';
    foreach ($rows as $row) {
        $label = isset($row['title']) ? $row['title'] : (isset($row['path']) ? $row['path'] : '');
        $url = isset($row['url']) ? $row['url'] : '';
        if ($url === '' && isset($row['path'])) {
            $url = home_url($row['path']);
        }
        echo '<li>' . esc_html($label);
        if ($url !== '') {
            echo ' — <a href="' . esc_url($url) . '">' . esc_html($url) . '</a>';
        }
        if (isset($row['words'])) {
            echo ' (' . (int) $row['words'] . ' words)';
        }
        $verdict = $url !== '' ? scr_inspection_text($url) : '';
        if ($verdict !== '') {
            echo '<br><span class="scr-badge is-muted">' . esc_html($verdict) . '</span>';
        }
        echo '</li>';
    }
    echo '</ul>';
}

function scr_admin_css() {
    return '.scr-app{max-width:1180px;color:#1d2327}'
        . '.scr-top{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;margin:8px 0 18px}'
        . '.scr-top h1{margin:0 0 4px;font-size:23px;line-height:1.3}'
        . '.scr-top p{margin:0;color:#646970}'
        . '.scr-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:0 0 16px}'
        . '.scr-stat{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:14px 16px}'
        . '.scr-stat b{display:block;font-size:22px;line-height:1.2}'
        . '.scr-stat span{color:#646970}'
        . '.scr-grid{display:grid;grid-template-columns:1.2fr .8fr;gap:16px}'
        . '.scr-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px 18px;margin:0 0 16px}'
        . '.scr-card h2{margin:0 0 10px;font-size:16px}.scr-card h3{margin:16px 0 6px;font-size:14px}'
        . '.scr-addons{display:grid;gap:10px}'
        . '.scr-addon{display:block;border:1px solid #dcdcde;border-radius:10px;padding:10px 12px}'
        . '.scr-badge{display:inline-block;border-radius:999px;padding:2px 8px;font-size:12px;font-weight:600}'
        . '.scr-badge.is-good{background:#edfaef;color:#007017}'
        . '.scr-badge.is-warn{background:#fcf9e8;color:#8a5a00}'
        . '.scr-badge.is-muted{background:#f0f0f1;color:#50575e}'
        . '.scr-app table.widefat{border:0;box-shadow:none}'
        . '.scr-factors{list-style:none;margin:0;padding:0;display:grid;gap:10px}'
        . '.scr-factors li{border:1px solid #dcdcde;border-radius:10px;padding:10px 12px}'
        . '.scr-factors li span:last-child{color:#50575e}'
        . '.scr-app summary{cursor:pointer;font-weight:600}'
        . '.scr-env{display:grid;grid-template-columns:160px 1fr;gap:6px 12px;margin:0}'
        . '.scr-env dt{color:#646970}'
        . '.scr-env dd{margin:0}'
        . '@media(max-width:960px){.scr-stats,.scr-grid{grid-template-columns:1fr}.scr-top{display:block}.scr-top .button{margin-top:12px}}';
}

function scr_state_badge($state) {
    $class = 'scr-badge';
    if ($state === 'Fixed on the site') {
        $class .= ' is-good';
    } elseif ($state === 'Needs you') {
        $class .= ' is-warn';
    } else {
        $class .= ' is-muted';
    }
    return '<span class="' . esc_attr($class) . '">' . esc_html($state) . '</span>';
}

function scr_environment() {
    global $wp_version;
    $seo = 'Not installed';
    if (defined('WPSEO_VERSION')) {
        $seo = 'Yoast ' . WPSEO_VERSION;
    } elseif (defined('RANK_MATH_VERSION')) {
        $seo = 'Rank Math';
    }
    $cache = 'Not detected';
    if (defined('LSCWP_V')) {
        $cache = 'LiteSpeed Cache';
    } elseif (defined('WP_ROCKET_VERSION')) {
        $cache = 'WP Rocket';
    } elseif (defined('WPCACHEHOME')) {
        $cache = 'WP Super Cache';
    }
    return array(
        'WordPress' => (string) $wp_version,
        'PHP' => PHP_VERSION,
        'Site' => home_url('/'),
        'SEO' => $seo,
        'Shop' => class_exists('WooCommerce') ? 'WooCommerce' : 'No shop plugin',
        'Cache' => $cache,
    );
}

function scr_google_redirect_uri() {
    return admin_url('admin.php?page=search-console-resolver');
}

function scr_google_client() {
    $client = get_option('scr_google_client', array());
    if (!is_array($client)) {
        return array('id' => '', 'secret' => '');
    }
    return array(
        'id' => isset($client['id']) ? (string) $client['id'] : '',
        'secret' => isset($client['secret']) ? (string) $client['secret'] : '',
    );
}

function scr_mask_secret($secret) {
    $secret = (string) $secret;
    if ($secret === '') {
        return '';
    }
    if (strlen($secret) <= 4) {
        return 'Saved';
    }
    return 'Saved ···' . substr($secret, -4);
}

function scr_sitekit_search_console_active() {
    if (!defined('GOOGLESITEKIT_VERSION') && !class_exists('\Google\Site_Kit\Plugin')) {
        return false;
    }
    $modules = get_option('googlesitekit_active_modules', array());
    return is_array($modules) && in_array('search-console', $modules, true);
}

function scr_sitekit_access_token() {
    if (!scr_sitekit_search_console_active() || !class_exists('\Google\Site_Kit\Plugin')) {
        return '';
    }
    try {
        $plugin = \Google\Site_Kit\Plugin::instance();
        if (!is_object($plugin) || !method_exists($plugin, 'authentication')) {
            return '';
        }
        $auth = $plugin->authentication();
        if (!is_object($auth) || !method_exists($auth, 'is_authenticated') || !$auth->is_authenticated()) {
            return '';
        }
        if (!method_exists($auth, 'get_oauth_client')) {
            return '';
        }
        $oauth = $auth->get_oauth_client();
        if (!is_object($oauth) || !method_exists($oauth, 'get_access_token')) {
            return '';
        }
        $token = $oauth->get_access_token();
        if (is_array($token) && !empty($token['access_token'])) {
            return (string) $token['access_token'];
        }
        return is_string($token) ? $token : '';
    } catch (Throwable $error) {
        return '';
    }
}

function scr_own_access_token() {
    $stored = get_option('scr_google_token', array());
    if (!is_array($stored) || empty($stored['refresh_token'])) {
        return '';
    }
    if (!empty($stored['access_token']) && !empty($stored['expires']) && (int) $stored['expires'] > time() + 60) {
        return (string) $stored['access_token'];
    }
    $client = scr_google_client();
    if ($client['id'] === '' || $client['secret'] === '') {
        return '';
    }
    $response = wp_remote_post('https://oauth2.googleapis.com/token', array(
        'timeout' => 15,
        'sslverify' => true,
        'body' => array(
            'client_id' => $client['id'],
            'client_secret' => $client['secret'],
            'refresh_token' => $stored['refresh_token'],
            'grant_type' => 'refresh_token',
        ),
    ));
    if (is_wp_error($response)) {
        return '';
    }
    $data = json_decode((string) wp_remote_retrieve_body($response), true);
    if (!is_array($data) || empty($data['access_token'])) {
        return '';
    }
    $stored['access_token'] = (string) $data['access_token'];
    $stored['expires'] = time() + (isset($data['expires_in']) ? (int) $data['expires_in'] : 3600);
    update_option('scr_google_token', $stored, false);
    return $stored['access_token'];
}

function scr_google_connection() {
    $sitekit = scr_sitekit_search_console_active();
    $sitekit_token = $sitekit ? scr_sitekit_access_token() : '';
    if ($sitekit_token !== '') {
        return array('token' => $sitekit_token, 'source' => 'Site Kit', 'sitekit' => true, 'sitekit_blocked' => false);
    }
    $own = scr_own_access_token();
    if ($own !== '') {
        return array('token' => $own, 'source' => 'This plugin', 'sitekit' => $sitekit, 'sitekit_blocked' => $sitekit);
    }
    return array('token' => '', 'source' => '', 'sitekit' => $sitekit, 'sitekit_blocked' => $sitekit);
}

function scr_google_notice($type, $text) {
    set_transient('scr_google_notice', array('type' => $type, 'text' => $text), MINUTE_IN_SECONDS);
}

function scr_take_google_notice() {
    $notice = get_transient('scr_google_notice');
    if (!is_array($notice)) {
        return array();
    }
    delete_transient('scr_google_notice');
    return $notice;
}

function scr_exchange_google_code($code) {
    $client = scr_google_client();
    if ($client['id'] === '' || $client['secret'] === '') {
        return new WP_Error('scr_google_client', 'Save the Google Client ID and Client secret before connecting.');
    }
    $response = wp_remote_post('https://oauth2.googleapis.com/token', array(
        'timeout' => 15,
        'sslverify' => true,
        'body' => array(
            'code' => $code,
            'client_id' => $client['id'],
            'client_secret' => $client['secret'],
            'redirect_uri' => scr_google_redirect_uri(),
            'grant_type' => 'authorization_code',
        ),
    ));
    if (is_wp_error($response)) {
        return $response;
    }
    $data = json_decode((string) wp_remote_retrieve_body($response), true);
    if (!is_array($data) || empty($data['access_token'])) {
        $message = is_array($data) && isset($data['error_description']) ? (string) $data['error_description'] : 'Google did not return a login.';
        return new WP_Error('scr_google_code', $message);
    }
    $stored = get_option('scr_google_token', array());
    if (!is_array($stored)) {
        $stored = array();
    }
    if (!empty($data['refresh_token'])) {
        $stored['refresh_token'] = (string) $data['refresh_token'];
    }
    if (empty($stored['refresh_token'])) {
        return new WP_Error('scr_google_refresh', 'Google did not return a refresh token. Disconnect any old grant for this client, then connect again.');
    }
    $stored['access_token'] = (string) $data['access_token'];
    $stored['expires'] = time() + (isset($data['expires_in']) ? (int) $data['expires_in'] : 3600);
    update_option('scr_google_token', $stored, false);
    delete_transient('scr_gsc_report_v18');
    return true;
}

function scr_google_api($method, $url, $body = null) {
    $connection = scr_google_connection();
    if ($connection['token'] === '') {
        return new WP_Error('scr_google_auth', 'Search Console is not connected.');
    }
    $args = array(
        'method' => $method,
        'timeout' => 20,
        'sslverify' => true,
        'headers' => array(
            'Authorization' => 'Bearer ' . $connection['token'],
            'Accept' => 'application/json',
        ),
    );
    if ($body !== null) {
        $args['headers']['Content-Type'] = 'application/json';
        $args['body'] = wp_json_encode($body);
    }
    $response = wp_remote_request($url, $args);
    if (is_wp_error($response)) {
        return $response;
    }
    $code = (int) wp_remote_retrieve_response_code($response);
    $data = json_decode((string) wp_remote_retrieve_body($response), true);
    if ($code < 200 || $code >= 300) {
        $message = is_array($data) && isset($data['error']['message']) ? (string) $data['error']['message'] : 'Google returned HTTP ' . $code;
        return new WP_Error('scr_google_http', $message);
    }
    return is_array($data) ? $data : array();
}

function scr_property_candidates() {
    $host = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));
    $bare = preg_replace('/^www\./', '', $host);
    $names = array();
    foreach (array($host, $bare, 'www.' . $bare) as $name) {
        if (!is_string($name) || $name === '' || $name === 'www.') {
            continue;
        }
        $names[$name] = $name;
    }
    $candidates = array();
    if ($bare !== '') {
        $candidates[] = 'sc-domain:' . $bare;
    }
    foreach ($names as $name) {
        $candidates[] = 'https://' . $name . '/';
        $candidates[] = 'http://' . $name . '/';
    }
    return $candidates;
}

function scr_match_property($entries) {
    $found = array();
    if (is_array($entries)) {
        foreach ($entries as $entry) {
            if (is_array($entry) && !empty($entry['siteUrl'])) {
                $found[] = (string) $entry['siteUrl'];
            }
        }
    }
    foreach (scr_property_candidates() as $candidate) {
        foreach ($found as $site) {
            if (strcasecmp(untrailingslashit($site), untrailingslashit($candidate)) === 0) {
                return array('property' => $site, 'properties' => $found);
            }
        }
    }
    return array('property' => '', 'properties' => $found);
}

function scr_inspect_budget() {
    $today = gmdate('Y-m-d');
    $log = get_option('scr_inspect_log', array());
    if (!is_array($log) || empty($log['date']) || $log['date'] !== $today) {
        $log = array('date' => $today, 'count' => 0);
    }
    $log['count'] = (int) $log['count'];
    return $log;
}

function scr_flagged_urls($report) {
    $urls = array();
    foreach (array('thin', 'noindex', 'broken', 'missing', 'matches') as $key) {
        if (empty($report[$key]) || !is_array($report[$key])) {
            continue;
        }
        foreach ($report[$key] as $row) {
            if (!is_array($row)) {
                continue;
            }
            $url = '';
            if (!empty($row['url'])) {
                $url = $row['url'];
            } elseif (!empty($row['target'])) {
                $url = $row['target'];
            } elseif (!empty($row['path'])) {
                $url = home_url($row['path']);
            }
            if ($url !== '' && scr_is_local_url($url)) {
                $clean = scr_clean_url($url);
                $urls[$clean] = $clean;
            }
        }
    }
    return array_values($urls);
}

function scr_inspection_text($url) {
    $all = get_option('scr_inspections', array());
    $key = scr_clean_url($url);
    if (!is_array($all) || empty($all[$key]) || !is_array($all[$key])) {
        return '';
    }
    $row = $all[$key];
    $parts = array();
    foreach (array('verdict', 'coverage', 'indexing') as $part) {
        if (!empty($row[$part])) {
            $parts[] = (string) $row[$part];
        }
    }
    if (!empty($row['crawled'])) {
        $parts[] = 'crawled ' . (string) $row['crawled'];
    }
    return implode(' · ', $parts);
}

function scr_inspect_flagged($property, $urls, &$report) {
    $stored = get_option('scr_inspections', array());
    if (!is_array($stored)) {
        $stored = array();
    }
    $log = scr_inspect_budget();
    $used = 0;
    foreach ($urls as $url) {
        if ($used >= 20 || $log['count'] >= 40) {
            break;
        }
        $key = scr_clean_url($url);
        if (!empty($stored[$key]['checked']) && (time() - (int) $stored[$key]['checked']) < 7 * DAY_IN_SECONDS) {
            continue;
        }
        $data = scr_google_api('POST', 'https://searchconsole.googleapis.com/v1/urlInspection/index:inspect', array(
            'inspectionUrl' => $url,
            'siteUrl' => $property,
        ));
        $log['count']++;
        $used++;
        if (is_wp_error($data)) {
            $report['inspect_error'] = $data->get_error_message();
            break;
        }
        $status = isset($data['inspectionResult']['indexStatusResult']) && is_array($data['inspectionResult']['indexStatusResult']) ? $data['inspectionResult']['indexStatusResult'] : array();
        $stored[$key] = array(
            'url' => $url,
            'verdict' => isset($status['verdict']) ? (string) $status['verdict'] : '',
            'coverage' => isset($status['coverageState']) ? (string) $status['coverageState'] : '',
            'crawled' => isset($status['lastCrawlTime']) ? (string) $status['lastCrawlTime'] : '',
            'indexing' => isset($status['indexingState']) ? (string) $status['indexingState'] : '',
            'checked' => time(),
        );
    }
    update_option('scr_inspect_log', $log, false);
    update_option('scr_inspections', $stored, false);
    $report['inspected'] = $used;
    $report['daily'] = $log['count'];
}

function scr_sync_google($inspect, $force_sitemap) {
    $connection = scr_google_connection();
    $log = scr_inspect_budget();
    $report = array(
        'source' => $connection['source'],
        'connected' => $connection['token'] !== '',
        'sitekit' => !empty($connection['sitekit']),
        'sitekit_blocked' => !empty($connection['sitekit_blocked']) && $connection['token'] === '',
        'error' => '',
        'property' => '',
        'properties' => array(),
        'sitemap_submitted' => '',
        'sitemap_error' => '',
        'performance' => array('clicks' => 0, 'impressions' => 0, 'pages' => array()),
        'performance_error' => '',
        'inspect_error' => '',
        'inspected' => 0,
        'daily' => $log['count'],
        'fetched' => time(),
    );
    if (!$report['connected']) {
        return $report;
    }
    $sites = scr_google_api('GET', 'https://www.googleapis.com/webmasters/v3/sites');
    if (is_wp_error($sites)) {
        $report['error'] = $sites->get_error_message();
        return $report;
    }
    $matched = scr_match_property(isset($sites['siteEntry']) ? $sites['siteEntry'] : array());
    $report['property'] = $matched['property'];
    $report['properties'] = $matched['properties'];
    if ($report['property'] === '') {
        return $report;
    }
    $encoded = rawurlencode($report['property']);
    $feed = home_url('/sitemap_index.xml');
    $sitemaps = scr_google_api('GET', 'https://www.googleapis.com/webmasters/v3/sites/' . $encoded . '/sitemaps');
    $listed = false;
    if (!is_wp_error($sitemaps) && !empty($sitemaps['sitemap']) && is_array($sitemaps['sitemap'])) {
        foreach ($sitemaps['sitemap'] as $row) {
            if (!is_array($row) || empty($row['path'])) {
                continue;
            }
            if (untrailingslashit((string) $row['path']) === untrailingslashit($feed)) {
                $listed = true;
                $report['sitemap_submitted'] = isset($row['lastSubmitted']) ? (string) $row['lastSubmitted'] : '';
            }
        }
    }
    if (!$listed || $force_sitemap) {
        $put = scr_google_api('PUT', 'https://www.googleapis.com/webmasters/v3/sites/' . $encoded . '/sitemaps/' . rawurlencode($feed));
        if (is_wp_error($put)) {
            $report['sitemap_error'] = $put->get_error_message();
        } else {
            $report['sitemap_submitted'] = gmdate('c');
        }
    }
    $end = gmdate('Y-m-d', time() - DAY_IN_SECONDS);
    $start = gmdate('Y-m-d', time() - (28 * DAY_IN_SECONDS));
    $totals = scr_google_api('POST', 'https://www.googleapis.com/webmasters/v3/sites/' . $encoded . '/searchAnalytics/query', array(
        'startDate' => $start,
        'endDate' => $end,
        'rowLimit' => 1,
    ));
    if (is_wp_error($totals)) {
        $report['performance_error'] = $totals->get_error_message();
    } elseif (!empty($totals['rows'][0]) && is_array($totals['rows'][0])) {
        $report['performance']['clicks'] = isset($totals['rows'][0]['clicks']) ? (int) $totals['rows'][0]['clicks'] : 0;
        $report['performance']['impressions'] = isset($totals['rows'][0]['impressions']) ? (int) $totals['rows'][0]['impressions'] : 0;
    }
    $pages = scr_google_api('POST', 'https://www.googleapis.com/webmasters/v3/sites/' . $encoded . '/searchAnalytics/query', array(
        'startDate' => $start,
        'endDate' => $end,
        'dimensions' => array('page'),
        'rowLimit' => 8,
    ));
    if (!is_wp_error($pages) && !empty($pages['rows']) && is_array($pages['rows'])) {
        foreach ($pages['rows'] as $row) {
            if (!is_array($row) || empty($row['keys'][0])) {
                continue;
            }
            $report['performance']['pages'][] = array(
                'url' => (string) $row['keys'][0],
                'clicks' => isset($row['clicks']) ? (int) $row['clicks'] : 0,
                'impressions' => isset($row['impressions']) ? (int) $row['impressions'] : 0,
            );
        }
    }
    if ($inspect) {
        scr_inspect_flagged($report['property'], scr_flagged_urls(scr_collect_report()), $report);
    }
    return $report;
}

function scr_google_report($refresh, $inspect, $force_sitemap) {
    if (!$refresh && !$force_sitemap) {
        $cached = get_transient('scr_gsc_report_v18');
        if (is_array($cached)) {
            return $cached;
        }
    }
    $report = scr_sync_google($inspect, $force_sitemap);
    set_transient('scr_gsc_report_v18', $report, 6 * HOUR_IN_SECONDS);
    return $report;
}

function scr_recent_inspections() {
    $all = get_option('scr_inspections', array());
    if (!is_array($all) || $all === array()) {
        return array();
    }
    uasort($all, function ($left, $right) {
        $left_time = is_array($left) && isset($left['checked']) ? (int) $left['checked'] : 0;
        $right_time = is_array($right) && isset($right['checked']) ? (int) $right['checked'] : 0;
        return $right_time - $left_time;
    });
    return array_slice($all, 0, 20);
}

function scr_render_search_console($google) {
    $client = scr_google_client();
    echo '<div class="scr-card"><h2>Search Console</h2>';
    if (!empty($google['error'])) {
        echo '<p>' . esc_html($google['error']) . '</p>';
    }
    if (!empty($google['connected'])) {
        echo '<p>Connected through ' . esc_html($google['source']) . '.</p>';
        if ($google['property'] !== '') {
            echo '<p>Property: <strong>' . esc_html($google['property']) . '</strong></p>';
            echo '<p>Sitemap: <a href="' . esc_url(home_url('/sitemap_index.xml')) . '">' . esc_html(home_url('/sitemap_index.xml')) . '</a>';
            if (!empty($google['sitemap_submitted'])) {
                echo ' · submitted ' . esc_html($google['sitemap_submitted']);
            }
            echo '</p>';
            if (!empty($google['sitemap_error'])) {
                echo '<p>' . esc_html($google['sitemap_error']) . '</p>';
            }
            echo '<p><a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=search-console-resolver&scr_resubmit=1'), 'scr_resubmit')) . '">Resubmit sitemap</a></p>';
            $performance = isset($google['performance']) && is_array($google['performance']) ? $google['performance'] : array();
            echo '<p>Last 28 days: ' . (int) (isset($performance['clicks']) ? $performance['clicks'] : 0) . ' clicks, ' . (int) (isset($performance['impressions']) ? $performance['impressions'] : 0) . ' impressions.</p>';
            if (!empty($google['performance_error'])) {
                echo '<p>' . esc_html($google['performance_error']) . '</p>';
            }
            if (!empty($performance['pages']) && is_array($performance['pages'])) {
                echo '<ul>';
                foreach ($performance['pages'] as $page) {
                    echo '<li><a href="' . esc_url($page['url']) . '">' . esc_html($page['url']) . '</a> · ' . (int) $page['clicks'] . ' clicks · ' . (int) $page['impressions'] . ' impressions</li>';
                }
                echo '</ul>';
            }
            echo '<p>URL inspections today: ' . (int) $google['daily'] . ' of 40. This refresh inspected ' . (int) $google['inspected'] . '.</p>';
            if (!empty($google['inspect_error'])) {
                echo '<p>' . esc_html($google['inspect_error']) . '</p>';
            }
            $inspections = scr_recent_inspections();
            if ($inspections !== array()) {
                echo '<ul>';
                foreach ($inspections as $row) {
                    if (!is_array($row) || empty($row['url'])) {
                        continue;
                    }
                    echo '<li><a href="' . esc_url($row['url']) . '">' . esc_html($row['url']) . '</a><br><span class="scr-badge is-muted">' . esc_html(trim($row['verdict'] . ' · ' . $row['coverage'] . ' · ' . $row['indexing'])) . '</span></li>';
                }
                echo '</ul>';
            }
        } else {
            echo '<p>This site was not in the properties for that Google account.</p>';
            if (!empty($google['properties']) && is_array($google['properties'])) {
                echo '<ul>';
                foreach ($google['properties'] as $property) {
                    echo '<li>' . esc_html($property) . '</li>';
                }
                echo '</ul>';
            }
        }
    } else {
        echo '<p>Sign in with the Google account that owns this site in Search Console. The verification tag alone cannot download the report.</p>';
        if (!empty($google['sitekit_blocked'])) {
            echo '<p>Site Kit is active, but this plugin could not reuse its Google login. Connect below.</p>';
        }
    }
    echo '<form method="post">';
    wp_nonce_field('scr_save_google_client', 'scr_google_client_nonce');
    echo '<p><label>Client ID<br><input class="large-text" type="text" name="scr_client_id" value="' . esc_attr($client['id']) . '"></label></p>';
    echo '<p><label>Client secret<br><input class="large-text" type="password" name="scr_client_secret" value="" placeholder="' . esc_attr($client['secret'] !== '' ? scr_mask_secret($client['secret']) : '') . '" autocomplete="new-password"></label></p>';
    echo '<p><label>Redirect URI<br><input class="large-text" type="text" readonly value="' . esc_attr(scr_google_redirect_uri()) . '"></label></p>';
    echo '<p><button class="button" type="submit">Save Google client</button></p></form>';
    if ($client['id'] !== '' && $client['secret'] !== '') {
        $connect = 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query(array(
            'client_id' => $client['id'],
            'redirect_uri' => scr_google_redirect_uri(),
            'response_type' => 'code',
            'scope' => 'https://www.googleapis.com/auth/webmasters',
            'access_type' => 'offline',
            'prompt' => 'consent',
            'state' => wp_create_nonce('scr_google_connect'),
        ));
        echo '<p><a class="button button-primary" href="' . esc_url($connect) . '">Connect Google</a></p>';
    }
    $own = get_option('scr_google_token', array());
    if (is_array($own) && !empty($own['refresh_token'])) {
        echo '<p><a href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=search-console-resolver&scr_disconnect=1'), 'scr_disconnect')) . '">Disconnect this plugin</a>. Site Kit stays connected.</p>';
    }
    echo '<p>Google does not provide the full Page indexing export, and this screen cannot press Validate fix. A refresh inspects at most 20 flagged URLs.</p></div>';
}

function scr_render_admin() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $refresh = false;
        if (isset($_GET['scr_refresh']) && isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'scr_refresh')) {
        delete_transient('scr_report_v19');
        delete_transient('scr_gsc_tag_v14');
        delete_transient('scr_gsc_report_v18');
        $refresh = true;
    }
    if (isset($_POST['scr_google_client_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['scr_google_client_nonce'])), 'scr_save_google_client')) {
        $existing = scr_google_client();
        $secret = isset($_POST['scr_client_secret']) ? trim((string) wp_unslash($_POST['scr_client_secret'])) : '';
        if ($secret === '') {
            $secret = $existing['secret'];
        }
        update_option('scr_google_client', array(
            'id' => isset($_POST['scr_client_id']) ? sanitize_text_field(wp_unslash($_POST['scr_client_id'])) : '',
            'secret' => $secret,
        ), false);
        delete_transient('scr_gsc_report_v18');
        scr_google_notice('success', 'Google client saved.');
    }
    if (isset($_GET['scr_disconnect']) && isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'scr_disconnect')) {
        delete_option('scr_google_token');
        delete_transient('scr_gsc_report_v18');
        scr_google_notice('success', 'This plugin’s Search Console login was removed.');
    }
    if (isset($_GET['code'], $_GET['state']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['state'])), 'scr_google_connect')) {
        $exchanged = scr_exchange_google_code(sanitize_text_field(wp_unslash($_GET['code'])));
        if (is_wp_error($exchanged)) {
            scr_google_notice('error', $exchanged->get_error_message());
        } else {
            scr_google_notice('success', 'Search Console is connected.');
        }
        wp_safe_redirect(admin_url('admin.php?page=search-console-resolver'));
        exit;
    }
    $redirect_applied = false;
    if (isset($_POST['scr_redirect_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['scr_redirect_nonce'])), 'scr_apply_redirect')) {
        $path = isset($_POST['scr_redirect_path']) ? (string) wp_unslash($_POST['scr_redirect_path']) : '';
        $target = isset($_POST['scr_redirect_target']) ? esc_url_raw(wp_unslash($_POST['scr_redirect_target'])) : '';
        foreach (scr_match_404s(get_option('scr_404_log', array())) as $row) {
            if (!is_array($row) || empty($row['suggestion'])) {
                continue;
            }
            if (scr_redirect_key($row['path']) !== scr_redirect_key($path)) {
                continue;
            }
            if (untrailingslashit($row['suggestion']) !== untrailingslashit($target) || !scr_is_local_url($target)) {
                continue;
            }
            $rules = get_option('scr_redirects', array());
            if (!is_array($rules)) {
                $rules = array();
            }
            $rules[scr_redirect_key($path)] = $target;
            update_option('scr_redirects', $rules, false);
            $redirect_applied = true;
        }
    }
    $addons_saved = false;
    if (isset($_POST['scr_addons_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['scr_addons_nonce'])), 'scr_save_addons')) {
        $posted = isset($_POST['scr_addon']) && is_array($_POST['scr_addon']) ? wp_unslash($_POST['scr_addon']) : array();
        $saved = array();
        foreach (array('clean_urls', 'attachments', 'images', 'sitemap') as $key) {
            $saved[$key] = !empty($posted[$key]);
        }
        update_option('scr_addons', $saved, false);
        $addons_saved = true;
    }
    $resubmit = isset($_GET['scr_resubmit'], $_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'scr_resubmit');
    $google = scr_google_report($refresh || $resubmit, $refresh, $resubmit);
    $google_notice = scr_take_google_notice();
    $verification = scr_find_verification();
    $report = scr_collect_report();
    $checks = array();
    if (isset($_POST['scr_urls']) && isset($_POST['scr_url_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['scr_url_nonce'])), 'scr_check_urls')) {
        $lines = preg_split('/\r\n|\n|\r/', wp_unslash($_POST['scr_urls']));
        $lines = is_array($lines) ? array_slice(array_unique(array_filter(array_map('trim', $lines))), 0, 15) : array();
        foreach ($lines as $line) {
            $checks[] = scr_check_url($line);
        }
    }
    $rows = scr_issue_rows($report);
    $fixed = 0;
    $needs = 0;
    foreach ($rows as $row) {
        if ($row[2] === 'Fixed on the site') {
            $fixed++;
        } elseif ($row[2] === 'Needs you') {
            $needs++;
        }
    }
    $actions = scr_priority_actions($report);
    $sitemap = isset($report['sitemap']) && is_array($report['sitemap']) ? $report['sitemap'] : array('url' => home_url('/sitemap_index.xml'), 'code' => 0, 'xml' => false);
    echo '<div class="wrap scr-app">';
    echo '<div class="scr-top"><div><h1>Search Console Resolver</h1><p>Version ' . esc_html(SCR_VERSION) . ' · Works on any WordPress site from 5.8 through 7.1</p></div>';
    echo '<a class="button button-primary" href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=search-console-resolver&scr_refresh=1'), 'scr_refresh')) . '">Refresh site check</a></div>';
    if ($addons_saved) {
        echo '<div class="notice notice-success"><p>Add-ons saved.</p></div>';
    }
    if ($redirect_applied) {
        echo '<div class="notice notice-success"><p>Redirect saved.</p></div>';
    }
    if ($google_notice !== array()) {
        $notice_class = (isset($google_notice['type']) && $google_notice['type'] === 'error') ? 'notice-error' : 'notice-success';
        echo '<div class="notice ' . esc_attr($notice_class) . '"><p>' . esc_html(isset($google_notice['text']) ? $google_notice['text'] : '') . '</p></div>';
    }
    echo '<div class="scr-stats">';
    echo '<div class="scr-stat"><b>' . (int) $fixed . '</b><span>Handled on this site</span></div>';
    echo '<div class="scr-stat"><b>' . (int) $needs . '</b><span>Still need you</span></div>';
    echo '<div class="scr-stat"><b>' . ($verification !== array() ? 'Verified' : 'No tag') . '</b><span>Search Console property</span></div>';
    echo '<div class="scr-stat"><b>' . (!empty($sitemap['xml']) ? 'XML' : 'Check') . '</b><span>Sitemap</span></div>';
    echo '</div>';
    if (!empty($report['factors']) && is_array($report['factors'])) {
        echo '<div class="scr-card"><h2>Other factors</h2><p>These checks run on any WordPress site. They do not change page text, titles, or theme files.</p><ul class="scr-factors">';
        foreach ($report['factors'] as $factor) {
            if (!is_array($factor)) {
                continue;
            }
            $good = isset($factor['state']) && $factor['state'] === 'good';
            echo '<li><span class="scr-badge ' . ($good ? 'is-good' : 'is-warn') . '">' . ($good ? 'OK' : 'Needs you') . '</span> <strong>' . esc_html(isset($factor['label']) ? $factor['label'] : '') . '</strong><br><span>' . esc_html(isset($factor['detail']) ? $factor['detail'] : '') . '</span></li>';
        }
        echo '</ul></div>';
    }
    echo '<div class="scr-grid"><div class="scr-card"><h2>Do these first</h2>';
    if ($actions === array()) {
        echo '<p>This check did not find a page that needs editing. The automatic fixes are still running.</p>';
    } else {
        echo '<ol>';
        foreach ($actions as $action) {
            echo '<li>' . esc_html($action) . '</li>';
        }
        echo '</ol>';
    }
    echo '</div><div class="scr-card"><h2>Automatic add-ons</h2>';
    echo '<p>These run on every theme. Google Ads click IDs stay in the URL.</p><form method="post">';
    wp_nonce_field('scr_save_addons', 'scr_addons_nonce');
    $addon_labels = array(
        'clean_urls' => array('Clean URLs', 'Send tracking links and comment-reply links to the real page.'),
        'attachments' => array('Attachment pages', 'Send thin attachment URLs to the media file.'),
        'images' => array('Image helper', 'Use the saved alt text, reserve space, and mark the first image.'),
        'sitemap' => array('Sitemap hygiene', 'Leave noindex posts and author archives out of the WordPress sitemap. Pages stay published.'),
    );
    echo '<div class="scr-addons">';
    foreach ($addon_labels as $key => $label) {
        echo '<label class="scr-addon"><input type="checkbox" name="scr_addon[' . esc_attr($key) . ']" value="1"' . (scr_addon_on($key) ? ' checked' : '') . '> <strong>' . esc_html($label[0]) . '</strong><br><span>' . esc_html($label[1]) . '</span></label>';
    }
    echo '</div><p><button class="button" type="submit">Save add-ons</button></p></form></div></div>';
    scr_render_search_console($google);
    if ($verification !== array()) {
        $last = (int) get_option('scr_last_auto_run');
        echo '<div class="scr-card"><h2>This property</h2><p>Search Console verification is on this website, so the daily check is tied to it.';
        if ($last > 0) {
            echo ' Last automatic check: ' . esc_html(wp_date('Y-m-d H:i', $last)) . '.';
        }
        echo '</p><ul>';
        foreach ($verification as $tag) {
            echo '<li>' . esc_html($tag['source'] . ': ' . scr_mask_id($tag['id'])) . '</li>';
        }
        echo '</ul><p>The tag proves the site is verified. Google removes a row after it recrawls the fixed URL. Use Validate fix in Search Console.</p></div>';
    } else {
        echo '<div class="scr-card"><h2>This property</h2><p>No verification tag was found in the homepage, Yoast, Rank Math, or Site Kit. The fixes still run. Add the Search Console meta tag when you want the daily check tied to that property.</p></div>';
    }
    echo '<div class="scr-card"><h2>Issue board</h2>';
    echo '<table class="widefat striped"><thead><tr><th>Group</th><th>Issue</th><th>State</th><th>What to do</th></tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr><td>' . esc_html($row[0]) . '</td><td>' . esc_html($row[1]) . '</td><td>' . scr_state_badge($row[2]) . '</td><td>' . esc_html($row[3]) . '</td></tr>';
    }
    echo '</tbody></table></div>';
    echo '<div class="scr-card"><details open><summary>Step-by-step guide for issues that still need you</summary>';
    echo '<p>Rows marked Fixed on the site are already handled. Open a list, do those steps, then use Validate fix or Request review in Search Console.</p>';
    $manual = 0;
    foreach (scr_issue_rows($report) as $row) {
        if ($row[2] !== 'Needs you' || empty($row[4])) {
            continue;
        }
        $manual++;
        echo '<h3>' . esc_html($row[0] . ' — ' . $row[1]) . '</h3><ol>';
        foreach ($row[4] as $step) {
            echo '<li>' . esc_html($step) . '</li>';
        }
        echo '</ol>';
    }
    if ($manual === 0) {
        echo '<p>Nothing in this check still needs a manual fix.</p>';
    }
    echo '</details></div>';
    echo '<div class="scr-card"><h2>Pages to edit</h2>';
    echo '<h3>Pages that need text</h3>';
    scr_render_url_list($report['thin']);
    echo '<h3>Pages with no links in the content</h3>';
    scr_render_url_list($report['unlinked']);
    echo '<h3>Password-protected or private items</h3>';
    scr_render_url_list($report['locked']);
    echo '<h3>Published items set to noindex</h3>';
    scr_render_url_list($report['noindex']);
    echo '<h3>Titles and descriptions to edit</h3>';
    if (empty($report['meta'])) {
        echo '<p>None in this check.</p>';
    } else {
        echo '<ul>';
        foreach ($report['meta'] as $row) {
            echo '<li>' . esc_html($row['title'] . ' — ' . $row['note']);
            if (!empty($row['edit'])) {
                echo ' — <a href="' . esc_url($row['edit']) . '">Edit</a>';
            }
            echo '</li>';
        }
        echo '</ul>';
    }
    echo '<h3>Internal links to check</h3>';
    if (empty($report['broken'])) {
        echo '<p>None in this check.</p>';
    } else {
        echo '<ul>';
        foreach ($report['broken'] as $row) {
            echo '<li>' . esc_html($row['title']) . ' links to <a href="' . esc_url($row['target']) . '">' . esc_html($row['target']) . '</a>';
            $verdict = scr_inspection_text($row['target']);
            if ($verdict !== '') {
                echo '<br><span class="scr-badge is-muted">' . esc_html($verdict) . '</span>';
            }
            echo '</li>';
        }
        echo '</ul>';
    }
    echo '<h3>Recent 404s</h3>';
    scr_render_url_list(is_array($report['missing']) ? $report['missing'] : array());
    echo '<h3>404s with a likely replacement</h3>';
    echo '<p>Apply redirect only when the suggested page is the real replacement. The plugin does not invent a target.</p>';
    $saved_rules = get_option('scr_redirects', array());
    if (!is_array($saved_rules)) {
        $saved_rules = array();
    }
    $suggested = 0;
    if (!empty($report['matches']) && is_array($report['matches'])) {
        echo '<ul>';
        foreach ($report['matches'] as $row) {
            if (empty($row['suggestion'])) {
                continue;
            }
            $suggested++;
            $rule_key = scr_redirect_key($row['path']);
            echo '<li>' . esc_html($row['path']) . ' → <a href="' . esc_url($row['suggestion']) . '">' . esc_html($row['suggestion_title']) . '</a>';
            $verdict = scr_inspection_text(isset($row['url']) ? $row['url'] : home_url($row['path']));
            if ($verdict !== '') {
                echo '<br><span class="scr-badge is-muted">' . esc_html($verdict) . '</span>';
            }
            if (isset($saved_rules[$rule_key])) {
                echo '<br>Redirect saved.';
            } else {
                echo '<form method="post">';
                wp_nonce_field('scr_apply_redirect', 'scr_redirect_nonce');
                echo '<input type="hidden" name="scr_redirect_path" value="' . esc_attr($row['path']) . '">';
                echo '<input type="hidden" name="scr_redirect_target" value="' . esc_attr($row['suggestion']) . '">';
                echo '<button class="button" type="submit">Apply redirect</button></form>';
            }
            echo '</li>';
        }
        echo '</ul>';
    }
    if ($suggested === 0) {
        echo '<p>None in this check.</p>';
    }
    echo '<h3>Sitemap to resubmit</h3>';
    echo '<p><a href="' . esc_url($sitemap['url']) . '">' . esc_html($sitemap['url']) . '</a> — HTTP ' . (int) $sitemap['code'] . ($sitemap['xml'] ? ', valid XML.' : ', not valid XML yet.') . '</p>';
    echo '<h3>PHP files inside uploads</h3>';
    if ($report['php'] === array()) {
        echo '<p>None in this check.</p>';
    } else {
        echo '<ul>';
        foreach ($report['php'] as $path) {
            echo '<li>' . esc_html($path) . '</li>';
        }
        echo '</ul>';
    }
    echo '<h3>Administrator accounts created in the last 14 days</h3>';
    if ($report['admins'] === array()) {
        echo '<p>None in this check.</p>';
    } else {
        echo '<ul>';
        foreach ($report['admins'] as $user) {
            echo '<li>' . esc_html($user['login'] . ' — ' . $user['registered']) . '</li>';
        }
        echo '</ul>';
    }
    echo '</div><div class="scr-card"><h2>This website</h2><dl class="scr-env">';
    foreach (scr_environment() as $label => $value) {
        echo '<dt>' . esc_html($label) . '</dt><dd>' . esc_html($value) . '</dd>';
    }
    echo '</dl><p>The same file runs on any WordPress site. It uses only supported hooks, so a WordPress automatic update does not require a plugin change. Yoast, Rank Math, WooCommerce, and the theme are all optional. A cache plugin can keep an old page for a while; use Refresh site check after you change a setting, and clear the site cache before you click Validate fix.</p></div>';
    echo '<div class="scr-card"><h2>Check URLs from Search Console</h2>';
    echo '<form method="post">';
    wp_nonce_field('scr_check_urls', 'scr_url_nonce');
    echo '<p><textarea name="scr_urls" rows="8" class="large-text" placeholder="https://example.com/page/">' . (isset($_POST['scr_urls']) ? esc_textarea(wp_unslash($_POST['scr_urls'])) : '') . '</textarea></p>';
    echo '<p><button class="button button-primary" type="submit">Check URLs</button></p>';
    echo '</form>';
    if ($checks !== array()) {
        echo '<h2>URL results</h2>';
        foreach ($checks as $check) {
            echo '<h3>' . esc_html($check['url']);
            if (!empty($check['code'])) {
                echo ' <span>HTTP ' . (int) $check['code'] . '</span>';
            }
            echo '</h3><ul>';
            foreach ($check['notes'] as $note) {
                echo '<li>' . esc_html($note) . '</li>';
            }
            echo '</ul>';
        }
    }
    echo '</div>';
}
