(function () {
    if (!window.SSMC) {
        return;
    }

    var status = document.getElementById('ssmc-status');
    var table = document.getElementById('ssmc-table');
    var body = table ? table.querySelector('tbody') : null;
    var scanButton = document.getElementById('ssmc-scan');
    var trashButton = document.getElementById('ssmc-trash');
    var selectAll = document.getElementById('ssmc-all');
    var progress = document.getElementById('ssmc-progress');
    var empty = document.getElementById('ssmc-empty');
    if (!status || !table || !body || !scanButton || !trashButton || !selectAll || !progress || !empty) {
        return;
    }

    function post(action, extra) {
        var data = new FormData();
        data.append('action', action);
        data.append('_ajax_nonce', window.SSMC.nonce);
        Object.keys(extra || {}).forEach(function (key) {
            var value = extra[key];
            if (Array.isArray(value)) {
                value.forEach(function (item) {
                    data.append(key + '[]', item);
                });
            } else {
                data.append(key, value);
            }
        });
        return fetch(window.SSMC.ajax, {
            method: 'POST',
            credentials: 'same-origin',
            body: data
        }).then(function (response) {
            return response.json();
        });
    }

    function addRow(item) {
        var id = Number(item.id) || 0;
        if (id < 1) {
            return;
        }
        var tr = document.createElement('tr');
        tr.dataset.id = String(id);

        var check = document.createElement('th');
        check.className = 'ssmc-check';
        check.scope = 'row';
        var box = document.createElement('input');
        box.type = 'checkbox';
        box.className = 'ssmc-pick';
        box.value = String(id);
        box.setAttribute('aria-label', item.filename || item.title || 'Select file');
        check.appendChild(box);

        var preview = document.createElement('td');
        if (item.thumb) {
            var img = document.createElement('img');
            img.alt = '';
            img.src = item.thumb;
            preview.appendChild(img);
        }

        var file = document.createElement('td');
        file.className = 'ssmc-file';
        var title = document.createElement('strong');
        title.textContent = item.title || '';
        var name = document.createElement('span');
        name.textContent = item.filename || '';
        file.appendChild(title);
        file.appendChild(name);

        var date = document.createElement('td');
        date.textContent = item.date || '';
        var size = document.createElement('td');
        size.textContent = item.size || '';

        tr.appendChild(check);
        tr.appendChild(preview);
        tr.appendChild(file);
        tr.appendChild(date);
        tr.appendChild(size);
        body.appendChild(tr);
    }

    function refreshTrash() {
        var boxes = body.querySelectorAll('.ssmc-pick');
        var picked = body.querySelectorAll('.ssmc-pick:checked').length;
        trashButton.disabled = picked === 0;
        selectAll.checked = boxes.length > 0 && picked === boxes.length;
        selectAll.indeterminate = picked > 0 && picked < boxes.length;
    }

    function setProgress(seen, total) {
        var pct = total > 0 ? Math.min(100, Math.round((seen / total) * 100)) : 0;
        progress.hidden = false;
        progress.setAttribute('aria-valuenow', String(pct));
        var bar = progress.querySelector('span');
        if (bar) {
            bar.style.width = pct + '%';
        }
    }

    function fail(message) {
        status.textContent = message;
        status.setAttribute('aria-busy', 'false');
        scanButton.disabled = false;
        refreshTrash();
    }

    function scan(offset, found) {
        scanButton.disabled = true;
        trashButton.disabled = true;
        selectAll.disabled = true;
        status.setAttribute('aria-busy', 'true');
        post('ssmc_scan', { offset: offset }).then(function (payload) {
            if (!payload || !payload.success) {
                fail('The scan could not continue. Reload the page and try again.');
                selectAll.disabled = false;
                return;
            }
            var data = payload.data || {};
            (data.items || []).forEach(addRow);
            found += (data.items || []).length;
            var seen = Number(data.next || 0);
            var total = Number(data.total || 0);
            setProgress(seen, total);
            status.textContent = 'Checked ' + seen + ' of ' + total + '. Unused files found: ' + found + '.';
            if (found > 0) {
                table.hidden = false;
                empty.hidden = true;
            }
            if (data.done) {
                table.hidden = found === 0;
                empty.hidden = found !== 0;
                scanButton.disabled = false;
                selectAll.disabled = false;
                status.setAttribute('aria-busy', 'false');
                if (found === 0) {
                    status.textContent = 'Checked ' + total + ' files. No unused files were found.';
                }
                refreshTrash();
                return;
            }
            if (seen <= offset) {
                fail('The scan stopped before the library was finished. Reload the page and try again.');
                selectAll.disabled = false;
                return;
            }
            scan(seen, found);
        }).catch(function () {
            fail('The scan could not continue. Reload the page and try again.');
            selectAll.disabled = false;
        });
    }

    scanButton.addEventListener('click', function () {
        body.textContent = '';
        selectAll.checked = false;
        selectAll.indeterminate = false;
        table.hidden = true;
        empty.hidden = true;
        setProgress(0, 0);
        status.textContent = 'Scanning the Media Library…';
        scan(0, 0);
    });

    body.addEventListener('change', refreshTrash);

    selectAll.addEventListener('change', function () {
        body.querySelectorAll('.ssmc-pick').forEach(function (box) {
            box.checked = selectAll.checked;
        });
        refreshTrash();
    });

    trashButton.addEventListener('click', function () {
        var ids = Array.prototype.map.call(body.querySelectorAll('.ssmc-pick:checked'), function (box) {
            return box.value;
        });
        if (!ids.length || !window.confirm('Move the selected files to the trash? You can restore them from Media, then Trash.')) {
            return;
        }
        trashButton.disabled = true;
        post('ssmc_trash', { ids: ids }).then(function (payload) {
            if (!payload || !payload.success) {
                status.textContent = 'Those files were not moved. Reload the page and try again.';
                refreshTrash();
                return;
            }
            var moved = payload.data && payload.data.trashed ? payload.data.trashed : [];
            moved.forEach(function (id) {
                var row = body.querySelector('tr[data-id="' + String(id).replace(/"/g, '') + '"]');
                if (row) {
                    row.parentNode.removeChild(row);
                }
            });
            var skipped = payload.data && payload.data.skipped ? payload.data.skipped.length : 0;
            status.textContent = moved.length + ' file' + (moved.length === 1 ? '' : 's') + ' moved to the trash.' + (skipped ? ' ' + skipped + ' stayed because they are still in use.' : '');
            table.hidden = body.children.length === 0;
            empty.hidden = body.children.length !== 0;
            refreshTrash();
        }).catch(function () {
            status.textContent = 'Those files were not moved. Reload the page and try again.';
            refreshTrash();
        });
    });
}());
