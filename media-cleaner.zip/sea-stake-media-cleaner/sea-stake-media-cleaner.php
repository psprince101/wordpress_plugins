<?php
/**
 * Plugin Name: Media Cleaner
 * Description: Works on any WordPress site. Finds unused media, compresses JPEG and PNG images, and safely minifies CSS and JavaScript without editing theme or plugin files.
 * Version: 1.2.4
 * Author: Sea Stake Infraventures
 * Author URI: https://seastakeinfraventures.com
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */

if (! defined('ABSPATH')) {
    exit;
}

define('SSMC_VERSION', '1.2.4');
define('SSMC_FILE', __FILE__);
define('SSMC_DIR', plugin_dir_path(__FILE__));

require_once SSMC_DIR . 'includes/class-scanner.php';
require_once SSMC_DIR . 'includes/class-admin.php';
require_once SSMC_DIR . 'includes/class-minify.php';
require_once SSMC_DIR . 'includes/class-images.php';
require_once SSMC_DIR . 'includes/class-speed.php';

add_action('plugins_loaded', static function (): void {
    SSMC_Admin::instance();
    SSMC_Speed::instance();
});

register_deactivation_hook(SSMC_FILE, static function (): void {
    wp_clear_scheduled_hook('ssmc_speed_cron');
});
