<?php

if (! defined('ABSPATH')) {
    exit;
}

class SSMC_Minify
{
    public function remember(string $src): void
    {
        $path = $this->local_path($src);
        if ($path === '') {
            return;
        }

        $queue = get_option('ssmc_minify_queue', []);
        if (! is_array($queue)) {
            $queue = [];
        }
        if (in_array($path, $queue, true) || count($queue) >= 40) {
            return;
        }

        $queue[] = $path;
        update_option('ssmc_minify_queue', $queue, false);
    }

    public function cached_url(string $src): string
    {
        $path = $this->local_path($src);
        if ($path === '') {
            return $src;
        }

        $cache = $this->cache_path($path);
        if (! is_file($cache) || filemtime($cache) < filemtime($path)) {
            $this->remember($src);

            return $src;
        }

        $url = content_url('cache/ssmc/' . $this->relative($path));
        $query = wp_parse_url($src, PHP_URL_QUERY);

        return $query ? $url . '?' . $query : $url;
    }

    public function drain(int $limit = 5): int
    {
        $queue = get_option('ssmc_minify_queue', []);
        if (! is_array($queue) || $queue === []) {
            return 0;
        }

        $done = 0;
        $left = [];
        foreach ($queue as $path) {
            if ($done >= $limit) {
                $left[] = $path;
                continue;
            }
            $this->build((string) $path);
            $done++;
        }
        update_option('ssmc_minify_queue', $left, false);

        return $done;
    }

    public function build(string $path): bool
    {
        if (! is_file($path) || ! is_readable($path)) {
            return false;
        }

        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if ($ext !== 'css' && $ext !== 'js') {
            return false;
        }
        $suffix = '.min.' . $ext;
        if (substr(basename($path), -strlen($suffix)) === $suffix) {
            return false;
        }

        $size = filesize($path);
        if ($size === false || $size < 80 || $size > 400000) {
            return false;
        }

        $raw = file_get_contents($path);
        if (! is_string($raw) || $raw === '') {
            return false;
        }

        $stripped = $this->strip_block_comments($raw);
        $min = $ext === 'css' ? $this->collapse_css($stripped) : $this->tidy_js($stripped);
        if ($min === '' || strlen($min) >= strlen($raw)) {
            return false;
        }
        if (! $this->same_structure($stripped, $min)) {
            return false;
        }

        $cache = $this->cache_path($path);
        $root = wp_normalize_path(WP_CONTENT_DIR . '/cache/ssmc');
        if (strpos($cache, $root . '/') !== 0) {
            return false;
        }
        wp_mkdir_p($root);
        wp_mkdir_p(dirname($cache));
        $this->guard($root);
        $this->guard(dirname($cache));

        return file_put_contents($cache, $min, LOCK_EX) !== false;
    }

    public function local_path(string $src): string
    {
        $src = (string) strtok($src, '?');
        if ($src === '') {
            return '';
        }

        $base = set_url_scheme(content_url());
        $src = set_url_scheme($src);
        if (strpos($src, $base) !== 0) {
            return '';
        }

        $relative = rawurldecode(substr($src, strlen($base)));
        $relative = ltrim(str_replace('\\', '/', $relative), '/');
        if ($relative === '' || strpos($relative, '..') !== false) {
            return '';
        }
        if (strpos($relative, 'cache/ssmc/') === 0) {
            return '';
        }

        $path = wp_normalize_path(WP_CONTENT_DIR . '/' . $relative);
        $root = wp_normalize_path(WP_CONTENT_DIR);
        if (strpos($path, $root . '/') !== 0 || ! is_file($path)) {
            return '';
        }

        return $path;
    }

    protected function cache_path(string $path): string
    {
        return wp_normalize_path(WP_CONTENT_DIR . '/cache/ssmc/' . $this->relative($path));
    }

    protected function relative(string $path): string
    {
        $root = wp_normalize_path(WP_CONTENT_DIR);
        $path = wp_normalize_path($path);
        if (strpos($path, $root . '/') !== 0) {
            return '';
        }

        return ltrim(substr($path, strlen($root)), '/');
    }

    protected function collapse_css(string $css): string
    {
        $out = '';
        $len = strlen($css);
        $quote = '';
        $space = false;
        for ($i = 0; $i < $len; $i++) {
            $ch = $css[$i];
            if ($quote !== '') {
                $out .= $ch;
                if ($ch === '\\' && $i + 1 < $len) {
                    $out .= $css[++$i];
                } elseif ($ch === $quote) {
                    $quote = '';
                }
                $space = false;
                continue;
            }
            if ($ch === '"' || $ch === "'") {
                if ($space && $out !== '' && ! $this->css_space_optional(substr($out, -1), $ch)) {
                    $out .= ' ';
                }
                $quote = $ch;
                $out .= $ch;
                $space = false;
                continue;
            }
            if ($ch === ' ' || $ch === "\n" || $ch === "\r" || $ch === "\t" || $ch === "\f") {
                $space = $out !== '';
                continue;
            }
            $prev = $out === '' ? '' : substr($out, -1);
            if ($space && ! $this->css_space_optional($prev, $ch)) {
                $out .= ' ';
            }
            $out .= $ch;
            $space = false;
        }

        return trim($out);
    }

    protected function css_space_optional(string $prev, string $next): bool
    {
        $tokens = ['{', '}', ';', ':', ','];

        return in_array($prev, $tokens, true) || in_array($next, $tokens, true);
    }

    protected function tidy_js(string $js): string
    {
        $lines = preg_split("/\r\n|\n|\r/", $js) ?: [];
        $kept = [];
        foreach ($lines as $line) {
            $line = rtrim($line);
            if ($line !== '') {
                $kept[] = $line;
            }
        }

        return implode("\n", $kept);
    }

    protected function strip_block_comments(string $code): string
    {
        $out = '';
        $len = strlen($code);
        $quote = '';
        for ($i = 0; $i < $len; $i++) {
            $ch = $code[$i];
            if ($quote !== '') {
                $out .= $ch;
                if ($ch === '\\' && $i + 1 < $len) {
                    $out .= $code[++$i];
                } elseif ($ch === $quote) {
                    $quote = '';
                }
                continue;
            }
            if ($ch === '"' || $ch === "'" || $ch === '`') {
                $quote = $ch;
                $out .= $ch;
                continue;
            }
            if ($ch === '/' && $i + 1 < $len && $code[$i + 1] === '*') {
                $end = strpos($code, '*/', $i + 2);
                if ($end === false) {
                    $out .= substr($code, $i);
                    break;
                }
                $i = $end + 1;
                continue;
            }
            $out .= $ch;
        }

        return $out;
    }

    protected function same_structure(string $raw, string $min): bool
    {
        foreach (['{', '}', '(', ')', '[', ']'] as $char) {
            if (substr_count($raw, $char) !== substr_count($min, $char)) {
                return false;
            }
        }

        return true;
    }

    protected function guard(string $dir): void
    {
        if (! is_file($dir . '/index.php')) {
            file_put_contents($dir . '/index.php', "<?php\n// Silence is golden.\n");
        }
    }
}
