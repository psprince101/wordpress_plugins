<?php

if (! defined('ABSPATH')) {
    exit;
}

class SSMC_Images
{
    public function compress_next(int $limit = 2): int
    {
        $ids = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => $limit,
            'fields' => 'ids',
            'post_mime_type' => ['image/jpeg', 'image/png'],
            'meta_query' => [
                [
                    'key' => '_ssmc_compressed',
                    'compare' => 'NOT EXISTS',
                ],
            ],
            'orderby' => 'ID',
            'order' => 'ASC',
        ]);

        $done = 0;
        foreach ($ids as $id) {
            $this->compress((int) $id);
            $done++;
        }

        return $done;
    }

    public function compress(int $id, $known = null): string
    {
        $post = get_post($id);
        if (! $post instanceof WP_Post || $post->post_type !== 'attachment') {
            return 'skipped';
        }

        $mime = (string) get_post_mime_type($id);
        if ($mime !== 'image/jpeg' && $mime !== 'image/png') {
            update_post_meta($id, '_ssmc_compressed', 'skipped');

            return 'skipped';
        }

        $main = get_attached_file($id);
        if (! is_string($main) || ! is_file($main)) {
            update_post_meta($id, '_ssmc_compressed', 'skipped');

            return 'skipped';
        }

        $files = [$main];
        $meta = is_array($known) ? $known : wp_get_attachment_metadata($id);
        if (is_array($meta) && ! empty($meta['sizes']) && is_array($meta['sizes'])) {
            $dir = dirname($main);
            foreach ($meta['sizes'] as $size) {
                if (! empty($size['file'])) {
                    $files[] = $dir . '/' . $size['file'];
                }
            }
        }

        $started = microtime(true);
        $changed = false;
        $finished = true;
        foreach (array_unique($files) as $file) {
            if (microtime(true) - $started > 8) {
                $finished = false;
                break;
            }
            if ($this->compress_file($id, $file)) {
                $changed = true;
            }
        }

        if (! $finished) {
            $tries = (int) get_post_meta($id, '_ssmc_compress_tries', true) + 1;
            update_post_meta($id, '_ssmc_compress_tries', $tries);
            if ($tries < 3) {
                return $changed ? 'compressed' : 'skipped';
            }
        }

        delete_post_meta($id, '_ssmc_compress_tries');
        if (! is_array($known)) {
            $fresh = wp_get_attachment_metadata($id);
            if (is_array($fresh) && is_file($main)) {
                $fresh['filesize'] = filesize($main);
                wp_update_attachment_metadata($id, $fresh);
            }
        }
        update_post_meta($id, '_ssmc_compressed', $changed ? 'yes' : 'no-gain');

        return $changed ? 'compressed' : 'skipped';
    }

    public function restore_all(): int
    {
        $ids = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => 20,
            'fields' => 'ids',
            'meta_key' => '_ssmc_backups',
        ]);

        $restored = 0;
        foreach ($ids as $id) {
            $backups = get_post_meta((int) $id, '_ssmc_backups', true);
            if (! is_array($backups)) {
                delete_post_meta((int) $id, '_ssmc_backups');
                continue;
            }
            foreach ($backups as $pair) {
                if (! is_array($pair)) {
                    continue;
                }
                $source = $this->inside_uploads((string) ($pair['backup'] ?? ''));
                $target = $this->inside_uploads((string) ($pair['file'] ?? ''));
                if ($source !== '' && $target !== '' && is_file($source) && copy($source, $target)) {
                    $restored++;
                }
            }
            delete_post_meta((int) $id, '_ssmc_backups');
            delete_post_meta((int) $id, '_ssmc_compressed');
        }

        return $restored;
    }

    protected function compress_file(int $id, string $file): bool
    {
        $file = wp_normalize_path($file);
        if (! is_file($file) || ! is_readable($file) || ! is_writable($file)) {
            return false;
        }

        $before = filesize($file);
        if ($before === false || $before < 30720 || $before > 8000000) {
            return false;
        }

        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if ($ext !== 'jpg' && $ext !== 'jpeg' && $ext !== 'png') {
            return false;
        }

        $editor = wp_get_image_editor($file);
        if (is_wp_error($editor)) {
            return false;
        }

        $temp = wp_tempnam('ssmc');
        if (! is_string($temp) || $temp === '' || ! copy($file, $temp)) {
            if (is_string($temp) && $temp !== '') {
                wp_delete_file($temp);
            }

            return false;
        }

        $editor->set_quality(82);
        $saved = $editor->save($file);
        if (is_wp_error($saved)) {
            copy($temp, $file);
            wp_delete_file($temp);

            return false;
        }

        $written = isset($saved['path']) ? wp_normalize_path((string) $saved['path']) : $file;
        if ($written !== $file) {
            $saved_ext = strtolower(pathinfo($written, PATHINFO_EXTENSION));
            if ($saved_ext !== $ext || ! is_file($written) || ! copy($written, $file)) {
                if (is_file($written) && $written !== $file) {
                    wp_delete_file($written);
                }
                copy($temp, $file);
                wp_delete_file($temp);

                return false;
            }
            if (is_file($written) && $written !== $file) {
                wp_delete_file($written);
            }
        }

        clearstatcache(true, $file);
        $after = filesize($file);
        if ($after === false || $after >= ($before * 0.95)) {
            copy($temp, $file);
            wp_delete_file($temp);

            return false;
        }

        $this->keep_backup($id, $file, $temp);
        wp_delete_file($temp);

        return true;
    }

    protected function keep_backup(int $id, string $file, string $temp): void
    {
        $relative = $this->relative($file);
        if ($relative === '') {
            return;
        }

        $uploads = wp_upload_dir();
        if (! empty($uploads['error'])) {
            return;
        }

        $dir = wp_normalize_path($uploads['basedir'] . '/ssmc-backups');
        if (! wp_mkdir_p($dir)) {
            return;
        }
        if (! is_file($dir . '/index.php')) {
            file_put_contents($dir . '/index.php', "<?php\n// Silence is golden.\n");
        }

        $name = $id . '-' . md5($file) . '-' . basename($file);
        $dest = $dir . '/' . $name;
        if (! is_file($dest) && ! copy($temp, $dest)) {
            return;
        }

        $backups = get_post_meta($id, '_ssmc_backups', true);
        if (! is_array($backups)) {
            $backups = [];
        }
        $backups[$name] = [
            'file' => $relative,
            'backup' => 'ssmc-backups/' . $name,
        ];
        update_post_meta($id, '_ssmc_backups', $backups);
    }

    protected function relative(string $file): string
    {
        $uploads = wp_upload_dir();
        $base = wp_normalize_path($uploads['basedir']);
        $file = wp_normalize_path($file);
        if (strpos($file, $base . '/') !== 0) {
            return '';
        }

        return ltrim(substr($file, strlen($base)), '/');
    }

    protected function inside_uploads(string $relative): string
    {
        $relative = ltrim(str_replace('\\', '/', $relative), '/');
        if ($relative === '' || strpos($relative, '..') !== false) {
            return '';
        }

        $uploads = wp_upload_dir();
        $base = wp_normalize_path($uploads['basedir']);
        $path = wp_normalize_path($base . '/' . $relative);
        if (strpos($path, $base . '/') !== 0) {
            return '';
        }

        return $path;
    }
}
