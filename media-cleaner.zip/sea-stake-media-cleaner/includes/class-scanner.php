<?php

if (! defined('ABSPATH')) {
    exit;
}

class SSMC_Scanner
{
    public const BATCH = 8;

    /** @var list<int>|null */
    protected $protected = null;

    /**
     * @return array{items: list<array<string, mixed>>, next: int, total: int, done: bool}
     */
    public function batch(int $offset): array
    {
        global $wpdb;

        $offset = max(0, $offset);
        $total = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_status = 'inherit'"
        );
        $ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_status = 'inherit' ORDER BY ID ASC LIMIT %d OFFSET %d",
            self::BATCH,
            $offset
        ));
        if (! is_array($ids)) {
            $ids = [];
        }

        $items = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($this->is_used($id)) {
                continue;
            }
            $items[] = $this->row($id);
        }

        $next = $offset + count($ids);

        return [
            'items' => $items,
            'next' => $next,
            'total' => $total,
            'done' => $ids === [] || $next >= $total,
        ];
    }

    public function is_used(int $id): bool
    {
        $post = get_post($id);
        if (! $post instanceof WP_Post || $post->post_type !== 'attachment' || $post->post_status !== 'inherit') {
            return true;
        }

        if (in_array($id, $this->protected_ids(), true)) {
            return true;
        }

        $file = (string) get_post_meta($id, '_wp_attached_file', true);
        $file = ltrim(str_replace('\\', '/', $file), '/');
        if ($file === '' || strpos($file, '..') !== false) {
            return true;
        }

        $base = basename($file);
        $stem = pathinfo($base, PATHINFO_FILENAME);
        if (strlen($stem) < 6) {
            return true;
        }

        $needles = [$file, $base];
        if (substr($stem, -7) === '-scaled') {
            $plain = substr($stem, 0, -7) . '.' . pathinfo($base, PATHINFO_EXTENSION);
            if ($plain !== '.' && $plain !== $base) {
                $needles[] = $plain;
            }
        }

        foreach (array_unique($needles) as $needle) {
            if ($this->needle_is_referenced((string) $needle, $id)) {
                return true;
            }
        }

        return $this->id_is_referenced($id);
    }

    /**
     * @return list<int>
     */
    public function protected_ids(): array
    {
        if (is_array($this->protected)) {
            return $this->protected;
        }

        $ids = [(int) get_option('site_icon')];
        $mods = get_theme_mods();
        if (is_array($mods) && isset($mods['custom_logo'])) {
            $ids[] = (int) $mods['custom_logo'];
        }

        global $wpdb;
        $logos = $wpdb->get_col("SELECT option_value FROM {$wpdb->options} WHERE option_name LIKE 'theme_mods_%'");
        foreach ($logos as $raw) {
            $decoded = maybe_unserialize($raw);
            if (is_array($decoded) && isset($decoded['custom_logo'])) {
                $ids[] = (int) $decoded['custom_logo'];
            }
        }

        $this->protected = array_values(array_filter(array_unique($ids)));

        return $this->protected;
    }

    /**
     * @return array{id: int, title: string, filename: string, date: string, size: string, thumb: string}
     */
    public function row(int $id): array
    {
        $file = get_attached_file($id);
        $bytes = is_string($file) && is_file($file) ? (int) filesize($file) : 0;
        $thumb = wp_get_attachment_image_url($id, 'thumbnail');

        return [
            'id' => $id,
            'title' => get_the_title($id) ?: '(no title)',
            'filename' => basename((string) get_post_meta($id, '_wp_attached_file', true)),
            'date' => get_the_date('d M Y', $id) ?: '',
            'size' => $bytes > 0 ? size_format($bytes) : 'Unknown',
            'thumb' => is_string($thumb) ? esc_url($thumb) : '',
        ];
    }

    protected function needle_is_referenced(string $needle, int $id): bool
    {
        global $wpdb;

        $like = '%' . $wpdb->esc_like($needle) . '%';
        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_type NOT IN ('attachment', 'revision')
               AND post_status NOT IN ('trash', 'auto-draft')
               AND (post_content LIKE %s OR post_excerpt LIKE %s)
             LIMIT 1",
            $like,
            $like
        ));
        if ($found) {
            return true;
        }

        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_id FROM {$wpdb->postmeta}
             WHERE post_id != %d
               AND meta_key NOT IN ('_wp_attached_file', '_wp_attachment_metadata', '_wp_attachment_backup_sizes', '_ssmc_backups')
               AND meta_value LIKE %s
             LIMIT 1",
            $id,
            $like
        ));
        if ($found) {
            return true;
        }

        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT option_id FROM {$wpdb->options}
             WHERE option_name NOT LIKE %s
               AND option_name NOT LIKE %s
               AND option_value LIKE %s
             LIMIT 1",
            $wpdb->esc_like('_transient') . '%',
            $wpdb->esc_like('_site_transient') . '%',
            $like
        ));
        if ($found) {
            return true;
        }

        $termmeta = $wpdb->termmeta;
        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_id FROM {$termmeta} WHERE meta_value LIKE %s LIMIT 1",
            $like
        ));

        return (bool) $found;
    }

    protected function id_is_referenced(int $id): bool
    {
        global $wpdb;

        $exact = (string) $id;
        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_id FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %s LIMIT 1",
            $exact
        ));
        if ($found) {
            return true;
        }

        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_id FROM {$wpdb->termmeta} WHERE meta_key = 'thumbnail_id' AND meta_value = %s LIMIT 1",
            $exact
        ));
        if ($found) {
            return true;
        }

        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_id FROM {$wpdb->postmeta}
             WHERE meta_key = '_product_image_gallery'
               AND (meta_value = %s OR meta_value LIKE %s OR meta_value LIKE %s OR meta_value LIKE %s)
             LIMIT 1",
            $exact,
            $wpdb->esc_like($exact . ',') . '%',
            '%' . $wpdb->esc_like(',' . $exact . ',') . '%',
            '%' . $wpdb->esc_like(',' . $exact)
        ));

        return (bool) $found;
    }
}
