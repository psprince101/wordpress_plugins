<?php

if (! defined('ABSPATH')) {
    exit;
}

class SSMC_Admin
{
    protected static ?self $instance = null;

    public static function instance(): self
    {
        if (! self::$instance instanceof self) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    protected function __construct()
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
        add_action('wp_ajax_ssmc_scan', [$this, 'scan']);
        add_action('wp_ajax_ssmc_trash', [$this, 'trash']);
    }

    public function menu(): void
    {
        add_media_page(
            'Media Cleaner',
            'Media Cleaner',
            'manage_options',
            'ssmc',
            [$this, 'render']
        );
    }

    public function assets(string $hook): void
    {
        if ($hook !== 'media_page_ssmc' && $hook !== 'media_page_ssmc-speed') {
            return;
        }

        wp_enqueue_style('ssmc-admin', plugins_url('assets/admin.css', SSMC_FILE), [], SSMC_VERSION);
        if ($hook !== 'media_page_ssmc') {
            return;
        }

        wp_enqueue_script('ssmc-admin', plugins_url('assets/admin.js', SSMC_FILE), [], SSMC_VERSION, true);
        wp_localize_script('ssmc-admin', 'SSMC', [
            'ajax' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ssmc'),
        ]);
    }

    public function chrome(string $current): void
    {
        $tabs = [
            'ssmc' => ['Unused media', admin_url('upload.php?page=ssmc')],
            'ssmc-speed' => ['Site speed', admin_url('upload.php?page=ssmc-speed')],
        ];
        ?>
        <header class="ssmc-hero">
            <div class="ssmc-hero-title">
                <span class="ssmc-mark" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"><rect x="3.5" y="5" width="17" height="14" rx="2"></rect><circle cx="8.5" cy="10" r="1.3" fill="#ffffff" stroke="none"></circle><path d="M3.5 15.5l4.2-3.2 2.8 2.1 3.2-2.4 6.8 4.2"></path></svg></span>
                <div>
                    <p class="ssmc-kicker">Media library and front-end speed</p>
                    <h1>Media Cleaner</h1>
                    <p class="ssmc-lead">Finds unused Media Library files, compresses JPEG and PNG images, and minifies CSS and JavaScript. Theme and plugin files stay untouched. It works on any WordPress site.</p>
                </div>
            </div>
            <span class="ssmc-version">Version <?php echo esc_html(SSMC_VERSION); ?></span>
        </header>
        <hr class="wp-header-end">
        <nav class="ssmc-tabs" aria-label="Media Cleaner sections">
            <?php foreach ($tabs as $slug => $tab) : ?>
                <a class="<?php echo $current === $slug ? 'is-current' : ''; ?>" href="<?php echo esc_url($tab[1]); ?>" <?php echo $current === $slug ? 'aria-current="page"' : ''; ?>><?php echo esc_html($tab[0]); ?></a>
            <?php endforeach; ?>
        </nav>
        <?php
    }

    public function render(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to clean media.', 'ssmc'));
        }
        ?>
        <div class="wrap ssmc-wrap">
            <?php $this->chrome('ssmc'); ?>
            <div class="ssmc-card">
                <h2>Unused files</h2>
                <p class="ssmc-help">The scan checks every file in the Media Library, including files uploaded today. It looks through saved content for each file’s name and upload path: pages, posts, products, menus, widgets, and customizer settings. It does not open the public website, and it ignores the file’s own Media Library record. Nothing is deleted. The logo, the site icon, and very short file names are left out. A file used only inside a theme stylesheet can still show up here, so check the preview before moving it. Selected files go to the trash and can be restored from Media, then Trash.</p>
                <div class="ssmc-actions">
                    <button type="button" class="button button-primary" id="ssmc-scan">Scan media library</button>
                    <button type="button" class="button ssmc-danger" id="ssmc-trash" disabled>Move selected to trash</button>
                </div>
                <p class="ssmc-status" id="ssmc-status" aria-live="polite">Not scanned yet.</p>
                <div class="ssmc-progress" id="ssmc-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" hidden>
                    <span></span>
                </div>
                <div class="ssmc-empty" id="ssmc-empty" hidden>
                    <strong>No unused files in this scan</strong>
                    <p>Everything in the Media Library is still referenced, or it is the logo, the site icon, or a very short file name.</p>
                </div>
                <div class="ssmc-results">
                    <table class="ssmc-table" id="ssmc-table" hidden>
                        <thead>
                            <tr>
                                <th class="ssmc-check"><input type="checkbox" id="ssmc-all" aria-label="Select all"></th>
                                <th>Preview</th>
                                <th>File</th>
                                <th>Date</th>
                                <th>Size</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <p class="ssmc-quiet">Image compression and CSS and JavaScript minifying are on the Site speed tab.</p>
        </div>
        <?php
    }

    public function scan(): void
    {
        $this->guard();
        $result = (new SSMC_Scanner())->batch((int) ($_POST['offset'] ?? 0));
        wp_send_json_success($result);
    }

    public function trash(): void
    {
        $this->guard();
        $ids = isset($_POST['ids']) ? (array) wp_unslash($_POST['ids']) : [];
        $ids = array_slice(array_unique(array_map('intval', $ids)), 0, 100);
        $scanner = new SSMC_Scanner();
        $trashed = [];
        $skipped = [];

        foreach ($ids as $id) {
            if ($id < 1 || $scanner->is_used($id) || ! current_user_can('delete_post', $id)) {
                $skipped[] = $id;
                continue;
            }
            $result = wp_trash_post($id);
            if ($result) {
                $trashed[] = $id;
            } else {
                $skipped[] = $id;
            }
        }

        wp_send_json_success([
            'trashed' => $trashed,
            'skipped' => $skipped,
        ]);
    }

    protected function guard(): void
    {
        if (! current_user_can('manage_options') || ! check_ajax_referer('ssmc', false, false)) {
            wp_send_json_error(['message' => 'Not allowed.'], 403);
        }
    }
}
