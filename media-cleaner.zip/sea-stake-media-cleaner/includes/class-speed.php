<?php

if (! defined('ABSPATH')) {
    exit;
}

class SSMC_Speed
{
    protected static ?self $instance = null;

    /** @var string|null */
    protected $optimizer_label = null;

    public static function instance(): self
    {
        if (! self::$instance instanceof self) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    protected function __construct()
    {
        add_filter('cron_schedules', [$this, 'schedule']);
        add_action('init', [$this, 'boot']);
        add_action('ssmc_speed_cron', [$this, 'cron']);
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_post_ssmc_speed_save', [$this, 'save']);
        add_filter('wp_generate_attachment_metadata', [$this, 'compress_upload'], 20, 2);
        add_filter('style_loader_src', [$this, 'style_src'], 20);
        add_filter('script_loader_src', [$this, 'script_src'], 20);
        add_filter('wp_get_attachment_image_attributes', [$this, 'image_attrs'], 20, 1);
    }

    /**
     * @param array<string, array{interval: int, display: string}> $schedules
     * @return array<string, array{interval: int, display: string}>
     */
    public function schedule(array $schedules): array
    {
        $schedules['ssmc_quarter'] = [
            'interval' => 15 * MINUTE_IN_SECONDS,
            'display' => 'Every 15 minutes',
        ];

        return $schedules;
    }

    public function boot(): void
    {
        $settings = $this->settings();
        if (! empty($settings['extras'])) {
            $this->extras();
        }

        $needs = ! empty($settings['compress']) || ! empty($settings['minify_css']) || ! empty($settings['minify_js']);
        if ($needs && ! wp_next_scheduled('ssmc_speed_cron')) {
            wp_schedule_event(time() + 120, 'ssmc_quarter', 'ssmc_speed_cron');
        }
        if (! $needs && wp_next_scheduled('ssmc_speed_cron')) {
            wp_clear_scheduled_hook('ssmc_speed_cron');
        }
    }

    public function cron(): void
    {
        $settings = $this->settings();
        if (! empty($settings['compress'])) {
            (new SSMC_Images())->compress_next(2);
        }
        if (! empty($settings['minify_css']) || ! empty($settings['minify_js'])) {
            (new SSMC_Minify())->drain(5);
        }
    }

    /**
     * @param mixed $meta
     * @param mixed $id
     * @return mixed
     */
    public function compress_upload($meta, $id)
    {
        $id = (int) $id;
        if (! is_array($meta) || empty($this->settings()['compress'])) {
            return $meta;
        }
        (new SSMC_Images())->compress($id, $meta);
        $file = get_attached_file($id);
        if (is_string($file) && is_file($file)) {
            $meta['filesize'] = filesize($file);
        }

        return $meta;
    }

    public function style_src($src)
    {
        return is_string($src) ? $this->maybe_min($src, 'css') : $src;
    }

    public function script_src($src)
    {
        return is_string($src) ? $this->maybe_min($src, 'js') : $src;
    }

    /**
     * @param array<string, string> $attr
     * @return array<string, string>
     */
    public function image_attrs(array $attr): array
    {
        if (empty($this->settings()['lazy']) || is_admin()) {
            return $attr;
        }
        if (! empty($attr['class']) && is_string($attr['class']) && preg_match('/(?:custom-logo|skip-lazy|no-lazy)/', $attr['class'])) {
            return $attr;
        }
        if (empty($attr['loading'])) {
            $attr['loading'] = 'lazy';
        }
        if (empty($attr['decoding'])) {
            $attr['decoding'] = 'async';
        }

        return $attr;
    }

    public function menu(): void
    {
        add_media_page(
            'Site speed',
            'Site speed',
            'manage_options',
            'ssmc-speed',
            [$this, 'render']
        );
    }

    public function render(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html('You are not allowed to change speed settings.'));
        }

        $settings = $this->settings();
        $optimizer = $this->other_optimizer();
        $queue = get_option('ssmc_minify_queue', []);
        $waiting = is_array($queue) ? count($queue) : 0;
        $compressed = $this->compressed_count();
        $minify_on = ! empty($settings['minify_css']) || ! empty($settings['minify_js']);
        $next = wp_next_scheduled('ssmc_speed_cron');
        $notice = $this->notice();
        ?>
        <div class="wrap ssmc-wrap">
            <?php SSMC_Admin::instance()->chrome('ssmc-speed'); ?>
            <?php if ($notice !== '') : ?>
                <div class="ssmc-banner is-ok" role="status"><?php echo esc_html($notice); ?></div>
            <?php endif; ?>
            <?php if ($optimizer !== '' && empty($settings['force_minify'])) : ?>
                <div class="ssmc-note"><strong><?php echo esc_html($optimizer); ?> is already active.</strong> CSS and JavaScript addresses stay unchanged so the two plugins do not rewrite the same files. Image compression, lazy loading, and the safe extras still run. Turn on “Minify anyway” only when the other plugin is not already minifying.</div>
            <?php endif; ?>
            <div class="ssmc-stats">
                <article class="ssmc-stat">
                    <span class="ssmc-stat-label">Images</span>
                    <strong><?php echo (int) $compressed; ?></strong>
                    <span class="ssmc-pill <?php echo empty($settings['compress']) ? 'is-off' : ''; ?>"><?php echo empty($settings['compress']) ? 'Off' : 'On'; ?></span>
                    <p>JPEG and PNG files already compressed.</p>
                </article>
                <article class="ssmc-stat">
                    <span class="ssmc-stat-label">CSS and JavaScript</span>
                    <strong><?php echo (int) $waiting; ?></strong>
                    <?php if (! $minify_on) : ?>
                        <span class="ssmc-pill is-off">Off</span>
                    <?php elseif ($optimizer !== '' && empty($settings['force_minify'])) : ?>
                        <span class="ssmc-pill is-wait">Held</span>
                    <?php else : ?>
                        <span class="ssmc-pill">On</span>
                    <?php endif; ?>
                    <p>Files waiting for a cache copy.</p>
                </article>
                <article class="ssmc-stat">
                    <span class="ssmc-stat-label">Next pass</span>
                    <strong><?php echo $next ? esc_html(wp_date('g:i a', $next)) : 'Idle'; ?></strong>
                    <span class="ssmc-pill <?php echo $next ? '' : 'is-off'; ?>"><?php echo $next ? 'Scheduled' : 'Not scheduled'; ?></span>
                    <p>A few images and files at a time, so the site does not stall.</p>
                </article>
            </div>
            <div class="ssmc-split">
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('ssmc_speed_save'); ?>
                    <input type="hidden" name="action" value="ssmc_speed_save">
                    <div class="ssmc-card">
                        <h2>Controls</h2>
                        <?php
                        $this->toggle('compress', 'Compress images', 'JPEG and PNG only. A file is replaced only when the new copy is at least 5% smaller, and the original is kept as a backup.', ! empty($settings['compress']));
                        $this->toggle('minify_css', 'Minify CSS', 'Enqueued CSS from this site is copied into a cache file. Already minified files are skipped.', ! empty($settings['minify_css']));
                        $this->toggle('minify_js', 'Minify JavaScript', 'Comments and blank lines are removed. Lines stay separate so scripts keep working.', ! empty($settings['minify_js']));
                        $this->toggle('force_minify', 'Minify anyway', 'Use this only when another speed plugin is active and it is not already minifying CSS or JavaScript.', ! empty($settings['force_minify']));
                        $this->toggle('lazy', 'Lazy-load images', 'Images load as they approach the screen. The logo, and any image marked skip-lazy, stays eager.', ! empty($settings['lazy']));
                        $this->toggle('extras', 'Safe extras', 'On the public site, drop the emoji script, unused head links, and the front-end heartbeat. The editor is left as it is.', ! empty($settings['extras']));
                        ?>
                        <div class="ssmc-actions">
                            <?php submit_button('Save speed settings', 'primary', 'submit', false); ?>
                        </div>
                    </div>
                </form>
                <div>
                    <div class="ssmc-card">
                        <h2>Run and restore</h2>
                        <p class="ssmc-help">One batch checks a few images and cached files. Restore puts original images back, 20 attachments at a time.</p>
                        <div class="ssmc-actions">
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                <?php wp_nonce_field('ssmc_speed_batch'); ?>
                                <input type="hidden" name="action" value="ssmc_speed_save">
                                <input type="hidden" name="batch" value="1">
                                <?php submit_button('Run a batch now', 'secondary', 'submit', false); ?>
                            </form>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('Restore the original images from the backups?');">
                                <?php wp_nonce_field('ssmc_speed_restore'); ?>
                                <input type="hidden" name="action" value="ssmc_speed_save">
                                <input type="hidden" name="restore" value="1">
                                <?php submit_button('Restore original images', 'secondary', 'submit', false); ?>
                            </form>
                        </div>
                    </div>
                    <div class="ssmc-card ssmc-gap">
                        <h2>Left with your host</h2>
                        <ul class="ssmc-list">
                            <li>Page cache, browser cache, and a CDN stay with your host or your existing cache plugin.</li>
                            <li>Theme and plugin files are never edited.</li>
                            <li>WebP, GIF, and files that are already small are left alone.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function save(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html('You are not allowed to change speed settings.'));
        }

        $url = admin_url('upload.php?page=ssmc-speed');
        if (isset($_POST['restore'])) {
            check_admin_referer('ssmc_speed_restore');
            $count = (new SSMC_Images())->restore_all();
            wp_safe_redirect(add_query_arg([
                'ssmc' => 'restored',
                'count' => $count,
            ], $url));
            exit;
        }

        if (isset($_POST['batch'])) {
            check_admin_referer('ssmc_speed_batch');
            $images = (new SSMC_Images())->compress_next(3);
            $files = (new SSMC_Minify())->drain(8);
            wp_safe_redirect(add_query_arg([
                'ssmc' => 'batch',
                'images' => $images,
                'files' => $files,
            ], $url));
            exit;
        }

        check_admin_referer('ssmc_speed_save');
        update_option('ssmc_speed', [
            'compress' => empty($_POST['compress']) ? 0 : 1,
            'minify_css' => empty($_POST['minify_css']) ? 0 : 1,
            'minify_js' => empty($_POST['minify_js']) ? 0 : 1,
            'force_minify' => empty($_POST['force_minify']) ? 0 : 1,
            'lazy' => empty($_POST['lazy']) ? 0 : 1,
            'extras' => empty($_POST['extras']) ? 0 : 1,
        ]);
        wp_safe_redirect(add_query_arg('ssmc', 'saved', $url));
        exit;
    }

    /**
     * @return array{compress: int, minify_css: int, minify_js: int, force_minify: int, lazy: int, extras: int}
     */
    public function settings(): array
    {
        $stored = get_option('ssmc_speed', []);
        $defaults = [
            'compress' => 1,
            'minify_css' => 1,
            'minify_js' => 1,
            'force_minify' => 0,
            'lazy' => 1,
            'extras' => 1,
        ];

        return array_merge($defaults, is_array($stored) ? $stored : []);
    }

    protected function toggle(string $name, string $title, string $text, bool $on): void
    {
        ?>
        <label class="ssmc-toggle">
            <input type="checkbox" name="<?php echo esc_attr($name); ?>" value="1" <?php checked($on); ?>>
            <span class="ssmc-switch" aria-hidden="true"></span>
            <span class="ssmc-toggle-copy">
                <strong><?php echo esc_html($title); ?></strong>
                <span><?php echo esc_html($text); ?></span>
            </span>
        </label>
        <?php
    }

    protected function notice(): string
    {
        $code = isset($_GET['ssmc']) ? sanitize_key(wp_unslash($_GET['ssmc'])) : '';
        if ($code === 'saved') {
            return 'Speed settings saved.';
        }
        if ($code === 'batch') {
            $images = isset($_GET['images']) ? absint($_GET['images']) : 0;
            $files = isset($_GET['files']) ? absint($_GET['files']) : 0;

            return $images . ' images checked. ' . $files . ' CSS or JavaScript files cached.';
        }
        if ($code === 'restored') {
            $count = isset($_GET['count']) ? absint($_GET['count']) : 0;

            return $count . ' image files restored. Run again if more backups remain.';
        }

        return '';
    }

    protected function compressed_count(): int
    {
        global $wpdb;

        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s",
            '_ssmc_compressed',
            'yes'
        ));
    }

    protected function maybe_min(string $src, string $kind): string
    {
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return $src;
        }

        $settings = $this->settings();
        $enabled = $kind === 'css' ? ! empty($settings['minify_css']) : ! empty($settings['minify_js']);
        if (! $enabled) {
            return $src;
        }
        if ($this->other_optimizer() !== '' && empty($settings['force_minify'])) {
            return $src;
        }

        $path = parse_url($src, PHP_URL_PATH);
        if (! is_string($path) || substr($path, -strlen('.' . $kind)) !== '.' . $kind) {
            return $src;
        }

        return (new SSMC_Minify())->cached_url($src);
    }

    protected function other_optimizer(): string
    {
        if ($this->optimizer_label !== null) {
            return $this->optimizer_label;
        }

        $map = [
            'litespeed-cache/' => 'LiteSpeed Cache',
            'wp-rocket/' => 'WP Rocket',
            'autoptimize/' => 'Autoptimize',
            'w3-total-cache/' => 'W3 Total Cache',
            'speed-optimizer/' => 'Speed Optimizer',
            'wp-optimize/' => 'WP-Optimize',
            'nitropack/' => 'NitroPack',
            'sg-cachepress/' => 'SiteGround Optimizer',
        ];
        $active = array_map('strval', (array) get_option('active_plugins', []));
        if (is_multisite()) {
            $network = get_site_option('active_sitewide_plugins', []);
            if (is_array($network)) {
                $active = array_merge($active, array_map('strval', array_keys($network)));
            }
        }

        foreach ($active as $plugin) {
            foreach ($map as $needle => $label) {
                if (strpos($plugin, $needle) === 0) {
                    $this->optimizer_label = $label;

                    return $label;
                }
            }
        }

        $this->optimizer_label = '';

        return '';
    }

    protected function extras(): void
    {
        remove_action('wp_head', 'print_emoji_detection_script', 7);
        remove_action('wp_print_styles', 'print_emoji_styles');
        remove_action('wp_head', 'rsd_link');
        remove_action('wp_head', 'wlwmanifest_link');
        remove_action('wp_head', 'wp_shortlink_wp_head');
        remove_action('wp_head', 'wp_generator');

        if (is_admin()) {
            return;
        }

        remove_filter('the_content_feed', 'wp_staticize_emoji');
        remove_filter('comment_text_rss', 'wp_staticize_emoji');
        remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
        add_filter('emoji_svg_url', '__return_false');
        add_filter('heartbeat_settings', static function ($settings) {
            if (! is_array($settings)) {
                $settings = [];
            }
            $settings['interval'] = 60;

            return $settings;
        });
        add_action('wp_enqueue_scripts', static function (): void {
            wp_deregister_script('heartbeat');
        }, 100);
    }
}
