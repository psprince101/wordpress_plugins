<?php

if (! defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('ssmc_speed');
delete_option('ssmc_minify_queue');
wp_clear_scheduled_hook('ssmc_speed_cron');
