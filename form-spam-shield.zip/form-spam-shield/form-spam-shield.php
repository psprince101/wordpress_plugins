<?php
/**
 * Plugin Name: Form Spam Shield
 * Description: Works on any WordPress site. Stops contact forms from emailing bot and junk submissions, without adding another captcha.
 * Version: 1.1.0
 * Author: Sea Stake Infraventures
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */

if (! defined('ABSPATH')) {
    exit;
}

define('FSS_VERSION', '1.1.0');
define('FSS_FILE', __FILE__);

register_uninstall_hook(FSS_FILE, 'fss_uninstall');

add_action('plugins_loaded', 'fss_boot', 20);
add_action('admin_menu', 'fss_menu');
add_action('admin_post_fss_save', 'fss_save');

function fss_uninstall() {
    delete_option('fss_settings');
    delete_option('fss_log');
    delete_option('fss_hp_name');
    delete_option('fss_block_count');
}

function fss_boot() {
    add_filter('wpcf7_form_elements', 'fss_honeypot_html');
    add_filter('wpcf7_spam', 'fss_cf7_spam', 20, 2);
    add_filter('wpcf7_display_message', 'fss_cf7_message', 20, 2);
    add_action('wpforms_display_submit_before', 'fss_echo_honeypot');
    add_action('wpforms_process', 'fss_wpforms_process', 10, 3);
    add_action('ninja_forms_display_after_fields', 'fss_echo_honeypot');
    add_filter('ninja_forms_submit_data', 'fss_ninja_submit');
    add_filter('gform_get_form_filter', 'fss_gravity_html', 20, 2);
    add_filter('gform_validation', 'fss_gravity_validation');
    add_filter('frm_filter_final_form', 'fss_insert_honeypot_html');
    add_filter('frm_validate_entry', 'fss_formidable_validate', 10, 2);
    add_action('everest_forms_display_submit_before', 'fss_echo_honeypot');
    add_action('everest_forms_process', 'fss_everest_process', 10, 3);
    add_filter('fluentform/validation_errors', 'fss_fluent_errors', 10, 3);
    add_action('elementor_pro/forms/validation', 'fss_elementor_validation', 10, 2);
    add_filter('elementor/widget/render_content', 'fss_elementor_widget', 20, 2);
    add_filter('forminator_custom_form_submit_errors', 'fss_forminator_errors', 10, 3);
    add_filter('pre_wp_mail', 'fss_pre_mail', 10, 2);
    add_action('wp_head', 'fss_honeypot_css', 20);
    add_action('wp_footer', 'fss_front_script', 20);
}

function fss_visitor_message() {
    return 'Your message could not be sent. Please check the form and try again.';
}

function fss_settings() {
    $stored = get_option('fss_settings', array());
    $defaults = array(
        'honeypot' => 1,
        'timing' => 1,
        'rate' => 1,
        'repeat' => 1,
        'content' => 1,
        'advanced' => 1,
    );
    $settings = array_merge($defaults, is_array($stored) ? $stored : array());
    foreach ($defaults as $key => $value) {
        unset($value);
        $settings[$key] = empty($settings[$key]) ? 0 : 1;
    }

    return $settings;
}

function fss_on($key) {
    $settings = fss_settings();

    return ! empty($settings[$key]);
}

function fss_hp_name() {
    $name = get_option('fss_hp_name', '');
    if (! is_string($name) || ! preg_match('/^fss_[a-f0-9]{8}$/', $name)) {
        $name = 'fss_' . substr(hash('sha256', wp_salt('auth') . 'honeypot'), 0, 8);
        update_option('fss_hp_name', $name, false);
    }

    return $name;
}

function fss_honeypot_markup() {
    $name = fss_hp_name();

    return '<p class="fss-hp" aria-hidden="true"><label>Leave this field empty <input type="text" name="' . esc_attr($name) . '" value="" tabindex="-1" autocomplete="off" data-lpignore="true" data-1p-ignore="true"></label></p>';
}

function fss_honeypot_html($html) {
    if (! fss_on('honeypot') || ! is_string($html) || strpos($html, fss_hp_name()) !== false) {
        return $html;
    }

    return $html . fss_honeypot_markup();
}

function fss_insert_honeypot_html($html) {
    if (! fss_on('honeypot') || ! is_string($html) || strpos($html, fss_hp_name()) !== false) {
        return $html;
    }
    $updated = preg_replace('/<form\b([^>]*)>/i', '<form$1>' . fss_honeypot_markup(), $html, 1);

    return is_string($updated) ? $updated : $html;
}

function fss_echo_honeypot() {
    if (fss_on('honeypot')) {
        echo fss_honeypot_markup();
    }
}

function fss_gravity_html($html, $form) {
    unset($form);

    return fss_insert_honeypot_html($html);
}

function fss_elementor_widget($content, $widget) {
    if (! fss_on('honeypot') || ! is_string($content) || ! is_object($widget) || ! method_exists($widget, 'get_name')) {
        return $content;
    }
    if (! in_array($widget->get_name(), array('form', 'metform'), true)) {
        return $content;
    }

    return fss_insert_honeypot_html($content);
}

function fss_honeypot_css() {
    if (is_admin() || ! fss_on('honeypot')) {
        return;
    }
    echo '<style>.fss-hp{position:absolute!important;left:-9999px!important;top:auto!important;width:1px!important;height:1px!important;overflow:hidden!important;}</style>' . "\n";
}

function fss_front_script() {
    if (is_admin() || (! fss_on('honeypot') && ! fss_on('timing'))) {
        return;
    }
    $config = wp_json_encode(array(
        'hp' => fss_hp_name(),
        'honeypot' => fss_on('honeypot') ? 1 : 0,
        'timing' => fss_on('timing') ? 1 : 0,
    ));
    echo '<script>window.fssCfg=' . $config . ';</script>' . "\n";
    echo "<script>(function(){var cfg=window.fssCfg||{};function wanted(form){if(!form||!form.matches||form.matches('form[role=\"search\"],.search-form,#searchform,#loginform,#registerform,.woocommerce-checkout')){return false;}return !!form.querySelector('input[type=\"email\"],textarea,input[name*=\"email\"],input[name*=\"message\"]');}function trap(form){if(!cfg.honeypot||!wanted(form)||form.querySelector('input[name=\"'+cfg.hp+'\"]')){return;}form.insertAdjacentHTML('afterbegin','<p class=\"fss-hp\" aria-hidden=\"true\"><label>Leave this field empty <input type=\"text\" name=\"'+cfg.hp+'\" value=\"\" tabindex=\"-1\" autocomplete=\"off\" data-lpignore=\"true\" data-1p-ignore=\"true\"></label></p>');}function stamp(form){if(!cfg.timing||!wanted(form)||document.cookie.indexOf('fss_t=')!==-1){return;}document.cookie='fss_t='+Math.floor(Date.now()/1000)+';path=/;max-age=7200;SameSite=Lax';}document.addEventListener('focusin',function(e){var form=e.target&&e.target.closest?e.target.closest('form'):null;trap(form);stamp(form);},true);document.addEventListener('DOMContentLoaded',function(){var forms=document.querySelectorAll('form'),i;for(i=0;i<forms.length;i++){trap(forms[i]);}});}());</script>\n";
}

function fss_cf7_spam($spam, $submission) {
    if ($spam || ! is_object($submission) || ! method_exists($submission, 'get_contact_form')) {
        return $spam;
    }
    $form = $submission->get_contact_form();
    $title = (is_object($form) && method_exists($form, 'title')) ? (string) $form->title() : 'Contact Form 7';

    return fss_decision($title) !== '';
}

function fss_cf7_message($message, $status) {
    if ($status === 'spam') {
        return fss_visitor_message();
    }

    return $message;
}

function fss_wpforms_process($fields, $entry, $form_data) {
    unset($fields, $entry);
    $title = isset($form_data['settings']['form_title']) ? (string) $form_data['settings']['form_title'] : 'WPForms';
    if (fss_decision($title) === '' || ! function_exists('wpforms')) {
        return;
    }
    $id = isset($form_data['id']) ? $form_data['id'] : 0;
    $process = wpforms()->process;
    if (is_object($process)) {
        $process->errors[$id]['header'] = fss_visitor_message();
    }
}

function fss_everest_process($fields, $entry, $form_data) {
    unset($fields, $entry);
    $title = isset($form_data['settings']['form_title']) ? (string) $form_data['settings']['form_title'] : 'Everest Forms';
    if (fss_decision($title) === '' || ! function_exists('evf')) {
        return;
    }
    $id = isset($form_data['id']) ? $form_data['id'] : 0;
    $process = evf()->process;
    if (is_object($process)) {
        $process->errors[$id]['header'] = fss_visitor_message();
    }
}

function fss_ninja_submit($form_data) {
    if (! is_array($form_data)) {
        return $form_data;
    }
    $title = 'Ninja Forms';
    if (! empty($form_data['settings']['title'])) {
        $title = (string) $form_data['settings']['title'];
    }
    if (fss_decision($title) !== '') {
        if (! isset($form_data['errors']) || ! is_array($form_data['errors'])) {
            $form_data['errors'] = array();
        }
        $form_data['errors']['form'] = array(fss_visitor_message());
    }

    return $form_data;
}

function fss_gravity_validation($result) {
    if (! is_array($result) || empty($result['form']['fields']) || ! is_array($result['form']['fields'])) {
        return $result;
    }
    $title = ! empty($result['form']['title']) ? (string) $result['form']['title'] : 'Gravity Forms';
    if (fss_decision($title) === '') {
        return $result;
    }
    $result['is_valid'] = false;
    foreach ($result['form']['fields'] as $index => $field) {
        if (is_object($field)) {
            $result['form']['fields'][$index]->failed_validation = true;
            $result['form']['fields'][$index]->validation_message = fss_visitor_message();
            break;
        }
    }

    return $result;
}

function fss_formidable_validate($errors, $values) {
    unset($values);
    if (! is_array($errors)) {
        $errors = array();
    }
    if (fss_decision('Formidable') !== '') {
        $errors['form'] = fss_visitor_message();
    }

    return $errors;
}

function fss_fluent_errors($errors, $form_data, $form) {
    unset($form_data);
    $title = 'Fluent Forms';
    if (is_object($form) && ! empty($form->title)) {
        $title = (string) $form->title;
    }
    if (fss_decision($title) === '') {
        return $errors;
    }
    if (! is_array($errors)) {
        $errors = array();
    }
    $errors['spam'] = array(fss_visitor_message());

    return $errors;
}

function fss_elementor_validation($record, $ajax_handler) {
    $title = 'Elementor form';
    if (is_object($record) && method_exists($record, 'get_form_settings')) {
        $settings = $record->get_form_settings();
        if (is_array($settings) && ! empty($settings['form_name'])) {
            $title = (string) $settings['form_name'];
        }
    }
    if (fss_decision($title) !== '' && is_object($ajax_handler) && method_exists($ajax_handler, 'add_error_message')) {
        $ajax_handler->add_error_message(fss_visitor_message());
    }
}

function fss_forminator_errors($errors, $form_id, $fields) {
    unset($form_id, $fields);
    if (fss_decision('Forminator') === '') {
        return $errors;
    }
    if (! is_array($errors)) {
        $errors = array();
    }
    $errors[] = fss_visitor_message();

    return $errors;
}

function fss_pre_mail($result, $atts = array()) {
    unset($atts);
    if ($result !== null) {
        return $result;
    }
    if (fss_decision('Website form') === '') {
        return null;
    }

    return true;
}

function fss_decision($label) {
    static $ready = false;
    static $reason = '';
    if ($ready) {
        return $reason;
    }
    $ready = true;
    if (! fss_is_form_request()) {
        return '';
    }
    $bundle = fss_bundle();
    $reason = fss_reason($bundle);
    if ($reason !== '') {
        fss_log($label, $reason);
    } else {
        fss_remember($bundle);
    }

    return $reason;
}

function fss_is_form_request() {
    if (! isset($_SERVER['REQUEST_METHOD']) || strtoupper((string) $_SERVER['REQUEST_METHOD']) !== 'POST') {
        return false;
    }
    if ((function_exists('wp_doing_cron') && wp_doing_cron()) || (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST)) {
        return false;
    }
    if (is_admin() && ! (function_exists('wp_doing_ajax') && wp_doing_ajax())) {
        return false;
    }
    $action = isset($_POST['action']) ? sanitize_key(wp_unslash($_POST['action'])) : '';
    if (in_array($action, array('heartbeat', 'upload-attachment', 'elementor_ajax', 'inline-save', 'oembed-cache', 'fss_save'), true)) {
        return false;
    }
    $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
    if (strpos($uri, 'wp-login.php') !== false || strpos($uri, 'wp-comments-post.php') !== false || isset($_POST['comment_post_ID'])) {
        return false;
    }
    if (! empty($_POST['woocommerce-process-checkout-nonce']) || ! empty($_POST['add-to-cart'])) {
        return false;
    }
    if (! empty($_POST['_wpcf7']) || ! empty($_POST['wpforms']) || ! empty($_POST['gform_submit']) || ! empty($_POST['frm_action']) || ! empty($_POST['everest_forms'])) {
        return true;
    }
    if (in_array($action, array('nf_ajax_submit', 'elementor_pro_forms_send_form', 'fluentform_submit', 'forminator_submit_form_custom-forms', 'metform_submit'), true)) {
        return true;
    }

    return fss_post_looks_like_form(wp_unslash($_POST));
}

function fss_post_looks_like_form($data, $depth = 0) {
    if ($depth > 4 || ! is_array($data)) {
        return false;
    }
    $email = false;
    $message = false;
    foreach ($data as $key => $value) {
        $segment = strtolower((string) $key);
        if (is_array($value)) {
            if (fss_post_looks_like_form($value, $depth + 1)) {
                return true;
            }
            continue;
        }
        $text = trim((string) $value);
        if (fss_is_email_key($segment) || (fss_is_email($text) && ! fss_is_message_key($segment))) {
            $email = true;
        }
        if (fss_is_message_key($segment)) {
            $message = true;
        }
    }

    return $email && $message;
}

function fss_bundle() {
    $bundle = array(
        'names' => array(),
        'emails' => array(),
        'messages' => array(),
        'bodies' => array(),
        'token' => false,
        'count' => 0,
    );
    fss_consume(wp_unslash($_POST), '', $bundle, 0);

    return $bundle;
}

function fss_consume($data, $hint, &$bundle, $depth) {
    if ($depth > 6 || $bundle['count'] > 200) {
        return;
    }
    if (! is_array($data)) {
        if (is_string($data)) {
            $raw = trim($data);
            if ($raw !== '' && ($raw[0] === '{' || $raw[0] === '[')) {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    fss_consume($decoded, $hint, $bundle, $depth + 1);
                    return;
                }
            }
        }
        $bundle['count']++;
        fss_place($hint, fss_text($data), $bundle);
        return;
    }
    $here = $hint;
    foreach (array('key', 'name', 'label', 'type') as $meta) {
        if (isset($data[$meta]) && is_scalar($data[$meta])) {
            $here .= ' ' . strtolower((string) $data[$meta]);
        }
    }
    if (array_key_exists('value', $data) && ! is_array($data['value'])) {
        $bundle['count']++;
        fss_place($here, fss_text($data['value']), $bundle);
    }
    foreach ($data as $key => $child) {
        if ($key === 'value' && ! is_array($child)) {
            continue;
        }
        if (in_array((string) $key, array('key', 'label', 'type', 'placeholder', 'settings', 'nonce'), true)) {
            continue;
        }
        fss_consume($child, trim($here . ' ' . strtolower((string) $key)), $bundle, $depth + 1);
    }
}

function fss_place($hint, $value, &$bundle) {
    if ($value === '') {
        return;
    }
    $hint = strtolower($hint);
    if (strpos($hint, 'recaptcha') !== false && strlen($value) > 20) {
        $bundle['token'] = true;
        return;
    }
    if (fss_skip_hint($hint)) {
        return;
    }
    if (fss_is_phone_key($hint) || (fss_is_phone($value) && ! fss_is_message_key($hint) && ! fss_is_name_key($hint))) {
        return;
    }
    if (fss_is_name_key($hint)) {
        $bundle['names'][] = $value;
        return;
    }
    if (fss_is_message_key($hint)) {
        $bundle['messages'][] = $value;
        if (strpos($hint, 'message') !== false || strpos($hint, 'comment') !== false || strpos($hint, 'body') !== false || strpos($hint, 'enquiry') !== false || strpos($hint, 'inquiry') !== false || strpos($hint, 'details') !== false) {
            $bundle['bodies'][] = $value;
        }
        return;
    }
    if (fss_is_email_key($hint) || fss_is_email($value)) {
        if (fss_is_email($value)) {
            $bundle['emails'][] = strtolower($value);
        }
        return;
    }
    if (preg_match('/(?:^|\s)\d+$/', $hint)) {
        if (fss_is_email($value)) {
            $bundle['emails'][] = strtolower($value);
        } elseif (preg_match('#https?://|www\.#i', $value) || strlen($value) >= 25) {
            $bundle['messages'][] = $value;
            $bundle['bodies'][] = $value;
        }
    }
}

function fss_text($value) {
    if (is_array($value)) {
        $value = implode(' ', $value);
    }
    $value = trim(wp_strip_all_tags((string) $value));
    if (strlen($value) > 8000) {
        $value = substr($value, 0, 8000);
    }

    return $value;
}

function fss_skip_hint($hint) {
    if (strpos($hint, fss_hp_name()) !== false) {
        return true;
    }

    return (bool) preg_match('/(^|[^a-z])(nonce|password|passwd|pwd|token|referer|action|security|captcha|form_name|form_id|post_id|page_id|unit_tag)([^a-z]|$)/', $hint);
}

function fss_is_email_key($hint) {
    return (bool) preg_match('/email|e-mail|(^|[^a-z])mail([^a-z]|$)/', $hint);
}

function fss_is_name_key($hint) {
    if (strpos($hint, 'user') !== false || strpos($hint, 'file') !== false) {
        return false;
    }

    return (bool) preg_match('/name|fname|lname/', $hint);
}

function fss_is_message_key($hint) {
    return (bool) preg_match('/message|subject|comment|enquiry|inquiry|body|details|question|content/', $hint);
}

function fss_is_phone_key($hint) {
    return (bool) preg_match('/phone|tel|mobile|whatsapp|number/', $hint);
}

function fss_is_email($value) {
    return (bool) preg_match('/^[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}$/i', $value);
}

function fss_is_phone($value) {
    $digits = preg_replace('/\D/', '', $value);

    return (bool) (strlen((string) $digits) >= 6 && preg_match('/^[+\d\s().\-]+$/', $value));
}

function fss_reason($bundle) {
    if (fss_on('honeypot')) {
        $name = fss_hp_name();
        $value = isset($_POST[$name]) ? fss_text(wp_unslash($_POST[$name])) : '';
        if ($value !== '') {
            return 'Honeypot was filled';
        }
    }
    if (fss_on('timing') && fss_timing_blocked($bundle)) {
        return 'Submitted too fast, or without the page script';
    }
    if (fss_on('advanced')) {
        $advanced = fss_advanced_reason($bundle);
        if ($advanced !== '') {
            return $advanced;
        }
    }
    if (fss_on('rate') && ! current_user_can('manage_options') && fss_rate_blocked($bundle['emails'])) {
        return 'Too many submissions from one address';
    }
    if (fss_on('content')) {
        $content = fss_content_reason($bundle);
        if ($content !== '') {
            return $content;
        }
    }
    if (fss_on('repeat') && fss_is_repeat($bundle)) {
        return 'Same email and message were sent recently';
    }

    return '';
}

function fss_timing_blocked($bundle) {
    $stamp = isset($_COOKIE['fss_t']) ? (int) $_COOKIE['fss_t'] : 0;
    if ($stamp < 1) {
        return empty($bundle['token']);
    }

    return (time() - $stamp) < 3;
}

function fss_advanced_reason($bundle) {
    $fields = array_merge($bundle['names'], $bundle['messages'], $bundle['emails']);
    foreach ($fields as $value) {
        if (fss_has_injection($value, in_array($value, $bundle['messages'], true))) {
            return 'Message tried to change the email headers';
        }
        if (fss_has_hidden_chars($value)) {
            return 'Hidden characters in the submission';
        }
    }
    foreach (array_merge($bundle['names'], $bundle['messages']) as $value) {
        if (fss_has_spam_phrase($value)) {
            return 'Known spam wording';
        }
    }
    if (fss_burst_blocked($bundle['bodies'])) {
        return 'The same message was sent repeatedly';
    }

    return '';
}

function fss_has_injection($value, $is_message) {
    if (! $is_message && preg_match('/[\r\n]/', $value)) {
        return true;
    }

    return (bool) preg_match('/(^|[\r\n])\s*(content-type|mime-version|bcc|cc)\s*:/i', $value);
}

function fss_has_hidden_chars($value) {
    $count = preg_match_all('/[\x{200B}-\x{200D}\x{FEFF}]/u', $value);

    return $count !== false && $count >= 3;
}

function fss_has_spam_phrase($value) {
    if (preg_match('/\b(viagra|cialis|casino|porn|xxx)\b/i', $value)) {
        return true;
    }
    $value = strtolower($value);
    foreach (array('buy backlinks', 'guest post', 'forex signal', 'crypto airdrop', 'seo service') as $phrase) {
        if (strpos($value, $phrase) !== false) {
            return true;
        }
    }

    return false;
}

function fss_burst_blocked($bodies) {
    $message = strtolower(trim(preg_replace('/\s+/', ' ', implode(' ', $bodies))));
    if (strlen($message) < 40) {
        return false;
    }
    $key = 'fss_b_' . substr(hash('sha256', $message . '|' . wp_salt('auth')), 0, 32);
    $count = (int) get_transient($key);
    if ($count >= 3) {
        return true;
    }
    set_transient($key, $count + 1, 30 * MINUTE_IN_SECONDS);

    return false;
}

function fss_client_hash() {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
    if ($ip === '') {
        return '';
    }

    return substr(hash('sha256', $ip . '|' . wp_salt('auth')), 0, 32);
}

function fss_rate_blocked($emails) {
    $keys = array();
    $ip = fss_client_hash();
    if ($ip !== '') {
        $keys[] = 'fss_r_' . $ip;
    }
    foreach ($emails as $email) {
        $keys[] = 'fss_e_' . substr(hash('sha256', strtolower($email) . '|' . wp_salt('auth')), 0, 32);
    }
    if ($keys === array()) {
        return false;
    }
    foreach ($keys as $key) {
        if ((int) get_transient($key) >= 4) {
            return true;
        }
    }
    foreach ($keys as $key) {
        set_transient($key, (int) get_transient($key) + 1, HOUR_IN_SECONDS);
    }

    return false;
}

function fss_content_reason($bundle) {
    foreach ($bundle['emails'] as $email) {
        if (substr_count($email, '@') !== 1) {
            return 'Email address is not usable';
        }
        $at = strrchr($email, '@');
        $domain = $at ? strtolower(substr($at, 1)) : '';
        if ($domain !== '' && in_array($domain, fss_disposable_domains(), true)) {
            return 'Disposable email address';
        }
    }
    foreach ($bundle['names'] as $name) {
        if (preg_match('#https?://|www\.|hxxps?://#i', $name) || strpos($name, '@') !== false) {
            return 'Link in the name';
        }
        if (fss_is_gibberish($name, 12)) {
            return 'Name looks like random letters';
        }
    }
    foreach ($bundle['messages'] as $message) {
        if (fss_link_count($message) > 2) {
            return 'Too many links in the message';
        }
        if (preg_match_all('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', $message) > 3) {
            return 'Too many email addresses in the message';
        }
        if (fss_is_gibberish($message, 40)) {
            return 'Message looks like random letters';
        }
    }

    return '';
}

function fss_link_count($text) {
    $count = preg_match_all('#https?://|www\.|hxxps?://#i', $text);
    if ($count === false) {
        $count = 0;
    }
    foreach (array('bit.ly', 'tinyurl.com', 'cutt.ly', 'is.gd', 'ow.ly', 'rebrand.ly', 'buff.ly') as $host) {
        $count += substr_count(strtolower($text), $host);
    }

    return $count;
}

function fss_disposable_domains() {
    return array(
        'mailinator.com', 'mailinator.net', 'mailinator.org', 'guerrillamail.com', 'guerrillamail.net',
        'guerrillamail.org', 'guerrillamail.biz', 'guerrillamailblock.com', 'sharklasers.com', 'grr.la',
        'yopmail.com', 'yopmail.fr', 'yopmail.net', 'tempmail.com', 'temp-mail.org', 'temp-mail.io',
        '10minutemail.com', '10minutemail.net', 'throwawaymail.com', 'trashmail.com', 'trashmail.de',
        'trashmail.org', 'getnada.com', 'mohmal.com', 'dispostable.com', 'mailnesia.com', 'maildrop.cc',
        'fakeinbox.com', 'mailnull.com', 'mailforspam.com', 'discard.email', 'spamgourmet.com',
        'tempail.com', 'mintemail.com', 'guerrillamail.info', 'emailondeck.com', 'tempmail.plus',
        'mailcatch.com', 'mytrashmail.com', 'spam4.me',
    );
}

function fss_is_gibberish($text, $minimum) {
    if (preg_match('/\d{6,}/', $text) || fss_is_phone($text)) {
        return false;
    }
    $letters = preg_match_all('/\p{L}/u', $text);
    if ($letters < 1) {
        return false;
    }
    $latin = preg_match_all('/[A-Za-z]/', $text);
    if (($latin / $letters) < 0.7) {
        return false;
    }
    $only = preg_replace('/[^A-Za-z]/', '', $text);
    $length = strlen((string) $only);
    if ($length < $minimum) {
        return false;
    }
    $vowels = preg_match_all('/[aeiouAEIOU]/', (string) $only);

    return ($vowels / $length) < 0.12;
}

function fss_repeat_key($bundle) {
    $email = isset($bundle['emails'][0]) ? strtolower($bundle['emails'][0]) : '';
    $message = strtolower(trim(preg_replace('/\s+/', ' ', implode(' ', $bundle['bodies']))));
    if ($email === '' || $message === '') {
        return '';
    }

    return 'fss_d_' . substr(hash('sha256', $email . '|' . $message . '|' . wp_salt('auth')), 0, 32);
}

function fss_is_repeat($bundle) {
    $key = fss_repeat_key($bundle);

    return $key !== '' && get_transient($key);
}

function fss_remember($bundle) {
    if (! fss_on('repeat')) {
        return;
    }
    $key = fss_repeat_key($bundle);
    if ($key !== '') {
        set_transient($key, 1, 30 * MINUTE_IN_SECONDS);
    }
}

function fss_log($form, $reason) {
    $log = get_option('fss_log', array());
    if (! is_array($log)) {
        $log = array();
    }
    array_unshift($log, array(
        'time' => time(),
        'form' => sanitize_text_field(substr((string) $form, 0, 80)),
        'reason' => sanitize_text_field(substr((string) $reason, 0, 120)),
    ));
    update_option('fss_log', array_slice($log, 0, 50), false);
    update_option('fss_block_count', (int) get_option('fss_block_count', 0) + 1, false);
}

function fss_catalog() {
    return array(
        'Contact Form 7' => defined('WPCF7_VERSION'),
        'WPForms' => function_exists('wpforms'),
        'Ninja Forms' => class_exists('Ninja_Forms'),
        'Gravity Forms' => class_exists('GFForms'),
        'Formidable' => class_exists('FrmForm'),
        'Fluent Forms' => defined('FLUENTFORM') || defined('FLUENTFORM_VERSION'),
        'Elementor Forms' => defined('ELEMENTOR_PRO_VERSION'),
        'Forminator' => class_exists('Forminator'),
        'Everest Forms' => function_exists('evf') || class_exists('EverestForms'),
        'MetForm' => defined('METFORM_VERSION') || class_exists('\MetForm\Plugin'),
    );
}

function fss_menu() {
    add_options_page('Form Spam Shield', 'Form Spam Shield', 'manage_options', 'form-spam-shield', 'fss_render');
}

function fss_render() {
    if (! current_user_can('manage_options')) {
        return;
    }
    $settings = fss_settings();
    $saved = isset($_GET['fss']) && sanitize_key(wp_unslash($_GET['fss'])) === 'saved';
    $log = get_option('fss_log', array());
    if (! is_array($log)) {
        $log = array();
    }
    $enabled = 0;
    foreach ($settings as $value) {
        $enabled += empty($value) ? 0 : 1;
    }
    $catalog = fss_catalog();
    $active = array();
    foreach ($catalog as $name => $on) {
        if ($on) {
            $active[] = $name;
        }
    }
    $rows = array(
        'honeypot' => array('Honeypot', 'A hidden field is added inside the form. People do not see it. A filled field is not emailed.'),
        'timing' => array('Timing', 'A submission in under 3 seconds, or one with no page script and no captcha token, is not emailed.'),
        'rate' => array('Rate limit', 'Four submissions an hour from one address, and four from the same email. The stored value is a hash. Administrators are not limited.'),
        'repeat' => array('Repeat message', 'The same email and message inside 30 minutes is sent once.'),
        'content' => array('Junk content', 'Blocks links in the name, more than two links, disposable inboxes, and long random Latin text. Hindi and phone numbers are left alone.'),
        'advanced' => array('Advanced traps', 'Stops header injection, hidden characters, a short list of known spam wording, and the same long message sent again and again.'),
    );
    ?>
    <div class="wrap fss-app">
        <header class="fss-head">
            <div>
                <p class="fss-kicker">Spam protection</p>
                <h1>Form Spam Shield</h1>
                <p>Stops junk from Contact Form 7, WPForms, Ninja Forms, Gravity Forms, Formidable, Fluent Forms, Elementor, Forminator, Everest Forms, and MetForm. Other form plugins are covered when they email the submission. No second captcha is added.</p>
            </div>
            <span class="fss-version"><?php echo esc_html(FSS_VERSION); ?></span>
        </header>
        <?php if ($saved) : ?>
            <div class="fss-note">Spam settings saved.</div>
        <?php endif; ?>
        <section class="fss-stats">
            <article><strong><?php echo esc_html((string) $enabled); ?></strong><span>Checks on</span></article>
            <article><strong><?php echo esc_html((string) (int) get_option('fss_block_count', 0)); ?></strong><span>Blocked</span></article>
            <article><strong><?php echo esc_html((string) count($active)); ?></strong><span><?php echo esc_html($active === array() ? 'Form plugins found' : implode(', ', $active)); ?></span></article>
        </section>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <?php wp_nonce_field('fss_save'); ?>
            <input type="hidden" name="action" value="fss_save">
            <section class="fss-card">
                <h2>Checks</h2>
                <?php foreach ($rows as $key => $row) : ?>
                    <label class="fss-row">
                        <span class="fss-copy">
                            <strong><?php echo esc_html($row[0]); ?></strong>
                            <span><?php echo esc_html($row[1]); ?></span>
                        </span>
                        <span class="fss-switch">
                            <input type="checkbox" name="fss_<?php echo esc_attr($key); ?>" value="1" <?php checked(! empty($settings[$key])); ?>>
                            <span></span>
                        </span>
                    </label>
                <?php endforeach; ?>
                <?php submit_button('Save spam settings'); ?>
            </section>
        </form>
        <section class="fss-card">
            <h2>Form plugins</h2>
            <p class="fss-muted">A highlighted name is active on this site. The others are ready when that plugin is installed.</p>
            <div class="fss-pills">
                <?php foreach ($catalog as $name => $on) : ?>
                    <span class="<?php echo $on ? 'is-on' : ''; ?>"><?php echo esc_html($name); ?></span>
                <?php endforeach; ?>
            </div>
        </section>
        <section class="fss-card">
            <h2>Recent blocks</h2>
            <p class="fss-muted">The latest 50 submissions that were not emailed. This list stores the time, form, and reason. It does not send another email.</p>
            <?php if ($log === array()) : ?>
                <div class="fss-empty">Nothing has been blocked yet.</div>
            <?php else : ?>
                <table>
                    <thead><tr><th>Time</th><th>Form</th><th>Reason</th></tr></thead>
                    <tbody>
                        <?php foreach ($log as $row) : ?>
                            <tr>
                                <td><?php echo esc_html(isset($row['time']) ? wp_date('d M Y, g:i a', (int) $row['time']) : ''); ?></td>
                                <td><?php echo esc_html(isset($row['form']) ? $row['form'] : ''); ?></td>
                                <td><span class="fss-pill"><?php echo esc_html(isset($row['reason']) ? $row['reason'] : ''); ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
    </div>
    <style>
        .fss-app{max-width:920px;color:#16222c}
        .fss-head{display:flex;justify-content:space-between;gap:24px;align-items:flex-end;margin:8px 0 18px}
        .fss-kicker{margin:0 0 4px;color:#0a5c50;font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
        .fss-app h1{margin:0;font-size:32px;line-height:1.1;font-weight:700}
        .fss-head p:last-child{max-width:68ch;margin:8px 0 0;color:#5c6b7a}
        .fss-version{background:#e7f5f2;color:#0a5c50;border-radius:999px;padding:6px 12px;font-weight:700}
        .fss-note{background:#e7f5f2;color:#0d5c50;border-radius:12px;padding:12px 14px;margin-bottom:14px}
        .fss-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-bottom:14px}
        .fss-stats article{background:#fff;border:1px solid #e6ebf1;border-radius:16px;padding:16px 18px;box-shadow:0 1px 2px rgba(22,34,44,.04)}
        .fss-stats strong{display:block;font-size:28px;line-height:1}
        .fss-stats span{display:block;margin-top:6px;color:#5c6b7a}
        .fss-card{background:#fff;border:1px solid #e6ebf1;border-radius:16px;padding:8px 18px 18px;margin:0 0 14px;box-shadow:0 1px 2px rgba(22,34,44,.04)}
        .fss-card h2{margin:14px 0 4px;font-size:16px}
        .fss-muted{color:#5c6b7a;margin-top:0}
        .fss-row{display:flex;gap:18px;align-items:center;justify-content:space-between;padding:14px 0;border-top:1px solid #eef2f6}
        .fss-row:first-of-type{border-top:0}
        .fss-copy{display:block;max-width:68ch}
        .fss-copy strong{display:block}
        .fss-copy span{display:block;margin-top:3px;color:#5c6b7a}
        .fss-switch{position:relative;width:46px;height:28px;flex:0 0 auto}
        .fss-switch input{position:absolute;opacity:0;width:46px;height:28px;margin:0;cursor:pointer}
        .fss-switch span{display:block;width:46px;height:28px;border-radius:999px;background:#d5dbe3;transition:background .15s}
        .fss-switch span:before{content:"";position:absolute;width:22px;height:22px;border-radius:50%;background:#fff;top:3px;left:3px;transition:transform .15s;box-shadow:0 1px 2px rgba(22,34,44,.2)}
        .fss-switch input:checked+span{background:#0e7c6b}
        .fss-switch input:checked+span:before{transform:translateX(18px)}
        .fss-switch input:focus-visible+span{outline:2px solid #0e7c6b;outline-offset:2px}
        .fss-app .button-primary{background:#0a5c50;border-color:#084c42;color:#fff;border-radius:999px;padding:2px 16px}
        .fss-app .button-primary:hover,.fss-app .button-primary:focus{background:#0c6b5d;border-color:#0a5c50}
        .fss-pills{display:flex;flex-wrap:wrap;gap:8px}
        .fss-pills span{border:1px solid #e1e7ee;border-radius:999px;padding:6px 10px;color:#5c6b7a;background:#f7f9fb}
        .fss-pills .is-on{background:#e7f5f2;border-color:#b7e4db;color:#0d5c50;font-weight:700}
        .fss-app table{width:100%;border-collapse:collapse}
        .fss-app th{text-align:left;font-size:12px;letter-spacing:.04em;text-transform:uppercase;color:#5c6b7a;padding:10px 8px;border-bottom:1px solid #e6ebf1}
        .fss-app td{padding:12px 8px;border-bottom:1px solid #f1f4f8;vertical-align:top}
        .fss-pill{display:inline-block;background:#fdecec;color:#8a3d3d;border-radius:999px;padding:3px 8px}
        .fss-empty{border:1px dashed #d5dbe3;border-radius:12px;padding:18px;color:#5c6b7a}
        @media (max-width:782px){.fss-head,.fss-row{display:block}.fss-stats{grid-template-columns:1fr}.fss-version,.fss-switch{margin-top:12px}}
    </style>
    <?php
}

function fss_save() {
    if (! current_user_can('manage_options')) {
        wp_die(esc_html('You are not allowed to change spam settings.'));
    }
    check_admin_referer('fss_save');
    $keys = array('honeypot', 'timing', 'rate', 'repeat', 'content', 'advanced');
    $settings = array();
    foreach ($keys as $key) {
        $settings[$key] = empty($_POST['fss_' . $key]) ? 0 : 1;
    }
    update_option('fss_settings', $settings, false);
    wp_safe_redirect(add_query_arg('fss', 'saved', admin_url('options-general.php?page=form-spam-shield')));
    exit;
}
